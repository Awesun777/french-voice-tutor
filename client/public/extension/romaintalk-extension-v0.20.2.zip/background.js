/**
 * background.js — the extension's only network layer.
 *
 * Every call to the tutor API happens here, in the MV3 service worker, and
 * never in the content script. Two reasons:
 *
 *   1. CORS. The server mounts tRPC with no CORS middleware, so a fetch from
 *      lemonde.fr's origin would be blocked outright. Service-worker fetches
 *      covered by `host_permissions` are not subject to CORS at all.
 *   2. The session cookie is httpOnly + SameSite=None (server/_core/cookies.ts),
 *      so `credentials: "include"` from here carries the user's real login.
 *      No API keys, no second auth system, nothing stored on disk.
 */

const DEFAULT_BASE = "https://romaintalk.com";

/**
 * Where the API lives. No UI writes apiBase anymore (the dev override was
 * removed for the store build); setting it by hand in chrome.storage from the
 * service-worker console still works for local development.
 */
async function getBase() {
  const stored = await chrome.storage.local.get("apiBase");
  return (stored.apiBase || DEFAULT_BASE).replace(/\/$/, "");
}

/** A tRPC error that survived the wire, with the code the UI branches on. */
class ApiError extends Error {
  constructor(message, code) {
    super(message);
    this.code = code;
  }
}

/**
 * The server uses the superjson transformer, so payloads are wrapped:
 * requests are {json: input} and responses are {result:{data:{json: value}}}.
 */
function unwrap(body) {
  if (body?.error) {
    const err = body.error.json ?? body.error;
    throw new ApiError(err?.message || "Request failed", err?.data?.code || "UNKNOWN");
  }
  const data = body?.result?.data;
  return data && "json" in data ? data.json : data;
}

/**
 * Not every response is tRPC JSON — a Railway cold start, a proxy 502 or a
 * redirect to a login page all return HTML, and `res.json()` on those throws a
 * syntax error that would surface to the user as "Unexpected token '<'".
 */
async function parse(res) {
  const text = await res.text();
  let body;
  try {
    body = JSON.parse(text);
  } catch {
    throw new ApiError(
      res.status >= 500 ? "Server is unavailable — try again in a moment." : `Unexpected response (HTTP ${res.status})`,
      res.status >= 500 ? "SERVER" : "PARSE"
    );
  }
  return unwrap(body);
}

async function trpcQuery(path) {
  const res = await fetch(`${await getBase()}/api/trpc/${path}`, {
    method: "GET",
    credentials: "include",
    headers: { "content-type": "application/json" },
  });
  return parse(res);
}

async function trpcMutate(path, input) {
  const res = await fetch(`${await getBase()}/api/trpc/${path}`, {
    method: "POST",
    credentials: "include",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ json: input }),
  });
  return parse(res);
}

// ─── Library cache ───────────────────────────────────────────────────────────
// Used only to answer "is this already saved?" without a round trip per lookup.
// The service worker is evicted often, so treat this as a bonus, never a source
// of truth — a miss just means we show the save button un-ticked.

let vocabCache = { at: 0, terms: null };
const VOCAB_TTL_MS = 60_000;

const norm = (s) => s.trim().toLowerCase();

async function savedTerms({ force = false } = {}) {
  if (!force && vocabCache.terms && Date.now() - vocabCache.at < VOCAB_TTL_MS) {
    return vocabCache.terms;
  }
  try {
    const list = await trpcQuery("vocab.list");
    const terms = new Set((list || []).map((v) => norm(v.term)));
    vocabCache = { at: Date.now(), terms };
    return terms;
  } catch {
    return vocabCache.terms || new Set();
  }
}

// ─── Actions ─────────────────────────────────────────────────────────────────

// ─── Local entry cache ───────────────────────────────────────────────────────
// The server cache already avoids regenerating an entry, but a cache hit still
// costs a round trip to Railway — and a cold container makes that round trip
// much worse than the query it performs. Keeping entries on this side means a
// word looked up twice is instant and needs no network at all.

const CACHE_PREFIX = "dict:";
const CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // entries are stable; a month is fine
const CACHE_MAX = 600;

const cacheKey = (term, parts) => `${CACHE_PREFIX}${parts}:${norm(term)}`;

async function cacheGet(term, parts) {
  const key = cacheKey(term, parts);
  try {
    const got = await chrome.storage.local.get(key);
    const hit = got[key];
    if (!hit) return null;
    if (Date.now() - hit.at > CACHE_TTL_MS) {
      chrome.storage.local.remove(key);
      return null;
    }
    return hit.value;
  } catch {
    return null;
  }
}

async function cachePut(term, parts, value) {
  try {
    await chrome.storage.local.set({ [cacheKey(term, parts)]: { at: Date.now(), value } });
    void trimCache();
  } catch { /* quota — not worth failing a lookup over */ }
}

/** Oldest-first eviction, run opportunistically rather than on every write. */
let trimming = false;
async function trimCache() {
  if (trimming) return;
  trimming = true;
  try {
    const all = await chrome.storage.local.get(null);
    const entries = Object.entries(all).filter(([k]) => k.startsWith(CACHE_PREFIX));
    if (entries.length <= CACHE_MAX) return;
    entries.sort((a, b) => (a[1]?.at ?? 0) - (b[1]?.at ?? 0));
    await chrome.storage.local.remove(entries.slice(0, entries.length - CACHE_MAX).map(([k]) => k));
  } catch { /* non-fatal */ } finally {
    trimming = false;
  }
}

/**
 * First paint. `parts: "meaning"` is a handful of output tokens rather than the
 * ~350 a quick entry costs, which is where the latency actually lives.
 *
 * The server answers a "meaning" request from a richer cached entry when it has
 * one, so this often comes back complete — `hasRest` tells the caller whether a
 * follow-up is needed at all.
 */
/** "ferme::t=noun::l=fr" — hints are part of the cache identity. */
const hintSuffix = (h) =>
  (h?.wordTypeHint ? `::t=${h.wordTypeHint}` : "") + (h?.langHint ? `::l=${h.langHint}` : "");
const hintParams = (h) => ({
  ...(h?.wordTypeHint ? { wordTypeHint: h.wordTypeHint } : {}),
  ...(h?.langHint ? { langHint: h.langHint } : {}),
});

async function lookup({ term, prefetch, hints }) {
  const ckey = term + hintSuffix(hints);
  const cached = await cacheGet(ckey, "meaning");
  const result = cached ?? (await trpcMutate("dictionary.search", { term, parts: "meaning", ...hintParams(hints) }));
  if (!cached) void cachePut(ckey, "meaning", result);

  // A prefetch is speculative: warm the caches, but don't spend a second call
  // asking the library about a word the user may never actually look up.
  if (prefetch) return { result, prefetched: true };

  const saved = await savedTerms();
  const headword =
    result?.type === "word" ? result.word : result?.type === "phrase" ? result.phrase : null;
  return {
    result,
    alreadySaved: headword ? saved.has(norm(headword)) : false,
    // Present only on a full entry, so it doubles as "is there more to fetch".
    hasRest: result?.examples === undefined,
  };
}

/** Everything below the meaning: examples, notes, grammar. */
async function lookupRest(term, hints) {
  const ckey = term + hintSuffix(hints);
  const cached = await cacheGet(ckey, "quick");
  if (cached) return cached;
  const result = await trpcMutate("dictionary.search", { term, parts: "quick", ...hintParams(hints) });
  void cachePut(ckey, "quick", result);
  return result;
}

async function lookupDetails(word) {
  const cached = await cacheGet(word, "details");
  if (cached) return cached;
  const result = await trpcMutate("dictionary.searchDetails", { word });
  void cachePut(word, "details", result);
  return result;
}

/**
 * Saves through the same `vocab.add` procedure the website's own dictionary
 * drawer uses, so entries land in one library with one shape — reviewable in
 * the Library tab, quizzable, and picked up by the SM-2 review queue.
 *
 * `lessonSource` records where you found it, which the Library renders under
 * the entry. That provenance is the whole point of looking words up in the wild.
 */
async function saveWord({ term, translation, entryKind, source }) {
  await trpcMutate("vocab.add", {
    term,
    translation,
    entryKind: entryKind || "word",
    lessonSource: (source || "Web").slice(0, 256),
  });
  // Keep the cache honest so the button stays ticked if you re-look-up the word.
  const terms = await savedTerms();
  terms.add(norm(term));
  vocabCache = { at: Date.now(), terms };
  return { ok: true };
}

async function ask({ message, context }) {
  return trpcMutate("tutor.contextChat", {
    message,
    vocabContext: context || undefined,
  });
}

/**
 * Server-side TTS rather than the browser's speechSynthesis: `voice.tts` is
 * prompted to read French phonetically even for words spelled like English ones
 * ("important", "table", "message"), which the local voices get wrong.
 *
 * Cached by text, as the website's usePronounce does, so replaying is free.
 */
const ttsCache = new Map();
const TTS_CACHE_MAX = 60;

async function tts({ text }) {
  const key = text.trim();
  if (!key) throw new ApiError("Nothing to pronounce", "EMPTY");
  if (ttsCache.has(key)) return ttsCache.get(key);

  // `voice.tts` caps input at 500 characters.
  const audio = await trpcMutate("voice.tts", { text: key.slice(0, 500) });
  if (ttsCache.size >= TTS_CACHE_MAX) ttsCache.delete(ttsCache.keys().next().value);
  ttsCache.set(key, audio);
  return audio;
}

// ─── Voice question (Shift+Return) ───────────────────────────────────────────

let offscreenReady = null;

/** Creates the recorder document once; concurrent callers share the promise. */
async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  if (!offscreenReady) {
    offscreenReady = chrome.offscreen
      .createDocument({
        url: "offscreen.html",
        reasons: ["USER_MEDIA"],
        justification: "Record a spoken French question for transcription.",
      })
      .catch((e) => {
        // A concurrent create can land first; that's success, not failure.
        if (!String(e?.message || e).includes("Only a single offscreen")) throw e;
      })
      .finally(() => (offscreenReady = null));
  }
  return offscreenReady;
}

async function toOffscreen(type) {
  await ensureOffscreen();
  return chrome.runtime.sendMessage({ target: "offscreen", type });
}

/** The tab whose dictation pill should receive level updates. */
let voiceLevelTabId = null;

async function voiceStart(sender) {
  voiceLevelTabId = sender?.tab?.id ?? null;
  const res = await toOffscreen("REC_START");
  if (!res?.ok) throw new ApiError(res?.error?.message || "Couldn't start recording", res?.error?.code || "REC_FAILED");
  return { ok: true };
}

async function voiceAbort() {
  await toOffscreen("REC_ABORT").catch(() => {});
  return { ok: true };
}

/**
 * Records a short clip and reports what happened, without transcribing it.
 *
 * "The microphone doesn't work" can mean the shortcut never fired, the offscreen
 * document was never created, getUserMedia was refused, or the upload failed —
 * and the card's single error message can't tell those apart. This exercises
 * exactly the recording path and nothing else, so a failure here is definitely
 * the microphone and a success here means the fault is downstream.
 */
async function voiceTest() {
  const steps = [];
  try {
    await ensureOffscreen();
    steps.push(`offscreen document: ${(await chrome.offscreen.hasDocument()) ? "created" : "MISSING"}`);
  } catch (e) {
    return { ok: false, steps, error: `offscreen document failed: ${e?.message || e}` };
  }

  const started = await toOffscreen("REC_START");
  if (!started?.ok) {
    steps.push(`getUserMedia: FAILED — ${started?.error?.name || "?"}`);
    return { ok: false, steps, error: started?.error?.message || "recording could not start" };
  }
  steps.push("getUserMedia: granted");

  await new Promise((r) => setTimeout(r, 1500));
  const rec = await toOffscreen("REC_STOP");
  if (!rec?.ok) {
    steps.push(`capture: FAILED — ${rec?.error?.code || "?"}`);
    return { ok: false, steps, error: rec?.error?.message || "capture failed" };
  }

  // base64 inflates by 4/3; the byte count is what says whether audio was real.
  const bytes = Math.round((rec.base64?.length || 0) * 0.75);
  steps.push(`captured: ${bytes.toLocaleString()} bytes of ${rec.mimeType}`);
  return { ok: true, steps, bytes };
}

/**
 * The voice question runs as two calls rather than voiceAsk's one, because the
 * palette reveals in two steps: the transcript paints the moment Whisper
 * returns, and the answer extends the card when the tutor is done. One
 * combined call would hold the fast half hostage to the slow one.
 */
async function voiceTranscribe() {
  const rec = await toOffscreen("REC_STOP");
  if (!rec?.ok) throw new ApiError(rec?.error?.message || "Recording failed", rec?.error?.code || "REC_FAILED");
  return trpcMutate("tutor.voiceTranscribe", {
    base64: rec.base64,
    mimeType: rec.mimeType,
    filename: rec.filename,
  });
}

/**
 * "How do you say …" turns the voice chat into a writing helper: the bare
 * French phrase is fetched in parallel with the tutor's answer so the client
 * can put a clean, paste-ready version on the clipboard. The tutor's prose —
 * markdown, alternatives, encouragement — is the wrong thing to paste.
 */
const SAY_TRIGGER =
  /^(?:how (?:do|would|does|can|could) (?:you|i|we|one) say|how to say|what(?:'s| is) the french (?:word |phrase )?for|comment dit[- ]on|comment est[- ]ce qu'on dit|comment on dit)[\s:,]+(.+?)(?:\s+in french|\s+en français)?\s*[?.!…]*$/i;

function sayTriggerPhrase(question) {
  const m = String(question || "").trim().match(SAY_TRIGGER);
  if (!m) return null;
  const phrase = m[1].trim().replace(/^["'«»""\s]+|["'«»""\s]+$/g, "");
  return phrase && phrase.length <= 300 ? phrase : null;
}

/**
 * Same message shape voiceAsk builds server-side, so the saved history reads
 * identically whichever path asked — and tutor.chat is the same answerAsTutor
 * underneath.
 */
async function voiceAnswer({ question, context }) {
  const message = context
    ? `Regarding this French text: "${String(context).slice(0, 500)}"\n\n${question}`
    : question;

  const phrase = sayTriggerPhrase(question);
  const [chat, french] = await Promise.all([
    // source:"voice" opts into the user's voice-model preference (Settings on
    // the website); typed asks stay on the default provider order.
    trpcMutate("tutor.chat", { message: String(message).slice(0, 2000), source: "voice" }),
    // Best-effort: a failed translation must never sink the answer itself.
    phrase ? trpcMutate("tutor.toFrench", { phrase }).catch(() => null) : Promise.resolve(null),
  ]);

  return french?.french ? { ...chat, copyText: french.french } : chat;
}

async function status() {
  const user = await trpcQuery("auth.me");
  return { signedIn: !!user, user, base: await getBase() };
}

// ─── Message routing ─────────────────────────────────────────────────────────

const handlers = {
  LOOKUP: (p) => lookup(p),
  LOOKUP_REST: ({ term, hints }) => lookupRest(term, hints),
  LOOKUP_DETAILS: ({ word }) => lookupDetails(word),
  SAVE_WORD: (p) => saveWord(p),
  ASK: (p) => ask(p),
  TTS: (p) => tts(p),
  VOICE_START: (_p, sender) => voiceStart(sender),
  VOICE_TRANSCRIBE: () => voiceTranscribe(),
  VOICE_ANSWER: (p) => voiceAnswer(p),
  VOICE_ABORT: () => voiceAbort(),
  VOICE_TEST: () => voiceTest(),
  // Which LLM answers ⌥S questions. Stored on the account (not
  // chrome.storage) so the website's Settings page shows the same choice.
  VOICE_MODEL_GET: () => trpcQuery("tutor.getVoiceModel"),
  VOICE_MODEL_SET: ({ model }) => trpcMutate("tutor.setVoiceModel", { model }),
  STATUS: () => status(),
  OPEN_APP: async () => {
    await chrome.tabs.create({ url: await getBase() });
    return { ok: true };
  },
  OPEN_MIC_SETUP: async () => {
    await chrome.tabs.create({ url: chrome.runtime.getURL("permission.html") });
    return { ok: true };
  },
  // The OAuth route directly — the user sees Google's consent screen, never
  // the website's pages; the callback sets the session cookie.
  OPEN_LOGIN: async () => {
    await chrome.tabs.create({ url: `${await getBase()}/api/auth/google/login` });
    return { ok: true };
  },
  SIGN_OUT: async () => {
    await trpcMutate("auth.logout", null).catch(() => {});
    return { ok: true };
  },
};

// Toolbar click opens the side panel (there is no popup any more).
chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Chords caught by keyhook.js inside a subframe (Google Docs' hidden input
  // frame, embedded editors) are forwarded to the top frame, where content.js
  // owns the card. frameId 0 is the top frame.
  if (msg?.type === "RELAY_KEY") {
    const tabId = sender?.tab?.id;
    if (tabId != null) {
      const fwd =
        msg.chord === "voice-down" ? { type: "TRIGGER_VOICE_DOWN" }
        : msg.chord === "voice-up" ? { type: "TRIGGER_VOICE_UP" }
        : { type: "TRIGGER_LOOKUP", selection: msg.selection };
      chrome.tabs.sendMessage(tabId, fwd, { frameId: 0 }).catch(() => {});
    }
    return false;
  }
  // Level ticks from the offscreen meter, relayed to the recording tab. Fire
  // and forget — a dropped frame of waveform is invisible.
  if (msg?.target === "level") {
    if (voiceLevelTabId != null) {
      chrome.tabs.sendMessage(voiceLevelTabId, { type: "VOICE_LEVEL", level: msg.level }).catch(() => {});
    }
    return false;
  }
  const handler = handlers[msg?.type];
  if (!handler) return false;
  handler(msg, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) =>
      sendResponse({
        ok: false,
        error: { message: err?.message || String(err), code: err?.code || "NETWORK" },
      })
    );
  return true; // keep the channel open for the async reply
});

// ─── Entry points ────────────────────────────────────────────────────────────

/**
 * Content scripts declared in the manifest only exist in tabs loaded after the
 * extension was installed or reloaded. Injecting on failure means the shortcut
 * works on already-open tabs too, instead of silently doing nothing — the
 * `activeTab` permission that the shortcut and context menu grant is what makes
 * this legal without broad scripting rights.
 */
/**
 * True on the tutor's own site. The extension deliberately stands down there:
 * the website binds the very same Shift+\ and Shift+Return, so without this
 * both would fire and two panels would open over each other. The website wins,
 * because it's the richer UI and it's already home.
 *
 * The manifest's `exclude_matches` covers this for normal injection, but
 * `scripting.executeScript` ignores exclude_matches entirely, so the guard has
 * to be repeated wherever we inject or dispatch by hand.
 */
async function isAppOrigin(url) {
  if (!url) return false;
  let origin;
  try {
    origin = new URL(url).origin;
  } catch {
    return false;
  }
  if (/^https:\/\/(www\.)?romaintalk\.com$/.test(origin)) return true;
  try {
    return new URL(await getBase()).origin === origin;
  } catch {
    return false;
  }
}

async function dispatch(tabId, payload) {
  try {
    await chrome.tabs.sendMessage(tabId, payload);
  } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
      await chrome.tabs.sendMessage(tabId, payload);
    } catch {
      // Restricted page (chrome://, the Web Store, a PDF viewer). Nothing to do.
    }
  }
}

/**
 * Alt+D is registered as a real chrome.commands binding — Chrome handles it
 * before the page ever sees the keydown, so no site can swallow it, and the
 * dispatch() fallback below injects into tabs that predate the install.
 *
 * content.js keeps its own Alt+D listener purely as a fallback: if another
 * extension owns the chord, the command never binds, but then the keydown
 * reaches the page and the content script catches it instead. The two can
 * never double-fire — a bound command consumes the keystroke entirely.
 *
 * Voice (Alt+S) is deliberately NOT a command: push-to-talk needs the keyup,
 * which the commands API does not expose.
 */
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  // On the app's own origin the content script stands down and RELAYS the
  // chord to the page instead (the site opens its own palette) — the command
  // binding consumed the keystroke browser-wide, so someone must forward it.
  if (command === "lookup-selection") dispatch(tab.id, { type: "TRIGGER_LOOKUP" });
});

// The context menu stays as the discoverable path that always works.
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "romain-lookup",
      title: 'Look up “%s” with Romain',
      contexts: ["selection"],
    });
    chrome.contextMenus.create({
      id: "romain-ask",
      title: 'Ask Romain about “%s”',
      contexts: ["selection"],
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;
  if (await isAppOrigin(tab.url)) return; // the website handles its own lookups
  const selection = info.selectionText || "";
  if (info.menuItemId === "romain-lookup") {
    dispatch(tab.id, { type: "TRIGGER_LOOKUP", selection });
  } else if (info.menuItemId === "romain-ask") {
    dispatch(tab.id, { type: "TRIGGER_ASK", selection });
  }
});
