/**
 * offscreen.js — microphone capture for the Alt+S voice question.
 *
 * Recording happens here rather than in the content script for two reasons:
 *
 *   1. A content script's getUserMedia runs against the *page's* origin, so it
 *      prompts once per site — and news sites that send
 *      `Permissions-Policy: microphone=()` block it outright, no prompt at all.
 *   2. An offscreen document runs on the chrome-extension:// origin, so the mic
 *      is granted once (from the popup) and then works on every site.
 *
 * Offscreen documents have no UI and so cannot show a permission prompt, which
 * is why the popup has to do the granting. Without that grant getUserMedia here
 * rejects immediately with NotAllowedError.
 */

/** Formats fall back in order — same list the website's recorder uses. */
const MIME_PREFS = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg"];

/** Below this there is nothing worth sending to a transcription model. */
const MIN_RECORDING_MS = 800;

function pickMime() {
  if (typeof MediaRecorder === "undefined") return "";
  return MIME_PREFS.find((t) => MediaRecorder.isTypeSupported(t)) ?? "";
}

function extFor(mime) {
  if (mime.includes("mp4")) return "mp4";
  if (mime.includes("ogg")) return "ogg";
  return "webm";
}

let recorder = null;
let stream = null;
let chunks = [];
let startedAt = 0;
let mime = "";
/** Live input level, so the page can draw a real waveform, not a fake one. */
let audioCtx = null;
let levelTimer = null;
/**
 * getUserMedia takes a few hundred ms, so a quick tap of the chord releases
 * before the recorder exists. Without this the stop finds nothing to stop and
 * the mic runs on with nobody holding a key.
 */
let stopWhenReady = false;
/** Resolved by stop(); held here because onstop fires asynchronously. */
let pendingStop = null;

function cleanup() {
  clearInterval(levelTimer);
  levelTimer = null;
  audioCtx?.close().catch(() => {});
  audioCtx = null;
  stream?.getTracks().forEach((t) => t.stop());
  stream = null;
  recorder = null;
}

/**
 * Streams the input level to the page while recording, ~12 times a second.
 * The dictation pill animates from these, so the bars move with the actual
 * voice rather than a canned loop — the difference between "it's recording"
 * and "it's hearing me".
 *
 * Routed via the service worker: runtime.sendMessage from an extension page
 * reaches other extension pages but never content scripts, so the worker
 * relays each level to the tab that started the recording.
 */
function startLevelMeter() {
  try {
    audioCtx = new AudioContext();
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 512;
    audioCtx.createMediaStreamSource(stream).connect(analyser);
    const buf = new Uint8Array(analyser.fftSize);
    levelTimer = setInterval(() => {
      analyser.getByteTimeDomainData(buf);
      let sum = 0;
      for (let i = 0; i < buf.length; i++) {
        const d = (buf[i] - 128) / 128;
        sum += d * d;
      }
      const rms = Math.sqrt(sum / buf.length);
      // RMS of speech at normal distance sits around 0.05–0.25; stretch it so
      // the bars use their range.
      chrome.runtime
        .sendMessage({ target: "level", level: Math.min(1, rms * 4.5) })
        .catch(() => {});
    }, 80);
  } catch {
    // No meter is a cosmetic loss, never a reason to fail the recording.
  }
}

async function start() {
  stopWhenReady = false;
  chunks = [];
  startedAt = Date.now();
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (e) {
    cleanup();
    const denied = e?.name === "NotAllowedError" || e?.name === "SecurityError";
    return {
      ok: false,
      error: {
        code: denied ? "MIC_DENIED" : "MIC_FAILED",
        // The raw DOMException name is the only thing that distinguishes "never
        // granted" from "granted but no device" from "another app holds it", so
        // it travels with the message rather than being flattened away.
        name: e?.name || "Error",
        message: denied
          ? `Microphone blocked (${e?.name}). Open the extension popup → Enable microphone.`
          : `Couldn't start the microphone (${e?.name}: ${e?.message || "unknown"}).`,
      },
    };
  }

  mime = pickMime();
  recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };
  recorder.onstop = async () => {
    cleanup();
    const elapsed = Date.now() - startedAt;
    const blob = new Blob(chunks, { type: mime || "audio/webm" });
    const resolve = pendingStop;
    pendingStop = null;
    if (!resolve) return;

    // Duration as well as size: byte counts vary wildly by codec, and a clip too
    // short to hold speech transcribes to an empty string, which surfaces as a
    // confusing "didn't catch that" after a needless round trip.
    if (elapsed < MIN_RECORDING_MS || blob.size < 1000) {
      resolve({
        ok: false,
        error: { code: "TOO_SHORT", message: "That was too short to hear — hold Alt+S while you speak." },
      });
      return;
    }

    const base64 = await new Promise((res, rej) => {
      const reader = new FileReader();
      reader.onload = () => res(String(reader.result).split(",")[1] ?? "");
      reader.onerror = () => rej(new Error("Couldn't read the recording"));
      reader.readAsDataURL(blob);
    }).catch(() => "");

    resolve(
      base64
        ? { ok: true, base64, mimeType: mime || "audio/webm", filename: `question.${extFor(mime)}` }
        : { ok: false, error: { code: "READ_FAILED", message: "Couldn't read the recording." } }
    );
  };

  recorder.start();
  startLevelMeter();
  // The keys were released while getUserMedia was still resolving.
  if (stopWhenReady) recorder.stop();
  return { ok: true };
}

function stop() {
  return new Promise((resolve) => {
    if (!recorder) {
      // Still inside getUserMedia — mark it and let start() stop it on arrival.
      stopWhenReady = true;
      pendingStop = resolve;
      // If the mic never comes up at all, don't leave the caller hanging.
      setTimeout(() => {
        if (pendingStop === resolve) {
          pendingStop = null;
          cleanup();
          resolve({ ok: false, error: { code: "TOO_SHORT", message: "That was too short to hear — hold Alt+S while you speak." } });
        }
      }, 3000);
      return;
    }
    // If the recorder exists but is already inactive, `onstop` will never fire
    // again — parking `resolve` here would hang the caller forever, leaving the
    // card stuck on "Transcribing…" with no error and no way back.
    if (recorder.state === "inactive") {
      cleanup();
      resolve({ ok: false, error: { code: "TOO_SHORT", message: "Nothing was recorded — hold Alt+S while you speak." } });
      return;
    }
    pendingStop = resolve;
    recorder.stop();
  });
}

function abort() {
  pendingStop = null;
  if (recorder && recorder.state !== "inactive") recorder.stop();
  cleanup();
  return { ok: true };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target !== "offscreen") return false;
  const run =
    msg.type === "REC_START" ? start()
    : msg.type === "REC_STOP" ? stop()
    : msg.type === "REC_ABORT" ? Promise.resolve(abort())
    : null;
  if (!run) return false;
  run.then(sendResponse).catch((e) =>
    sendResponse({ ok: false, error: { code: "REC_FAILED", message: e?.message || String(e) } })
  );
  return true;
});
