const $ = (id) => document.getElementById(id);

// ── Brand fonts, from the same bundled files the cards use ───────────────────
fetch("fonts/fonts.json")
  .then((r) => r.json())
  .then((fonts) => {
    for (const f of fonts) {
      // Extension page: FontFace from same-origin URLs, no CSP concerns.
      const family = f.family === "Roboto" ? "Roboto" : "Nunito Sans";
      const face = new FontFace(family, `url(fonts/${f.file})`, {
        weight: f.weight,
        style: f.style,
        unicodeRange: f.range,
      });
      face.load().then((loaded) => document.fonts.add(loaded)).catch(() => {});
    }
  })
  .catch(() => {});

// ── Header ───────────────────────────────────────────────────────────────────
$("ver").textContent = `v${chrome.runtime.getManifest().version}`;
$("logo").onclick = () => chrome.runtime.sendMessage({ type: "OPEN_APP" });

// ── Account ──────────────────────────────────────────────────────────────────
async function refreshAccount() {
  const res = await chrome.runtime.sendMessage({ type: "STATUS" }).catch(() => null);
  const acct = $("acct");
  const btn = $("auth");
  if (res?.ok && res.data.signedIn) {
    const u = res.data.user;
    acct.textContent = `Signed in as ${u?.email || u?.name || "your account"}`;
    btn.textContent = "Sign out";
    btn.className = "flat";
    btn.style.display = "";
    btn.onclick = async () => {
      await chrome.runtime.sendMessage({ type: "SIGN_OUT" }).catch(() => {});
      refreshAccount();
    };
  } else if (res?.ok) {
    acct.textContent = "Not signed in";
    btn.textContent = "Continue with Google";
    btn.className = "flat primary";
    btn.style.display = "";
    // Opens the OAuth route directly — only Google's consent screen, never the
    // website UI. The callback sets the session cookie the extension rides on.
    btn.onclick = () => chrome.runtime.sendMessage({ type: "OPEN_LOGIN" });
  } else {
    acct.textContent = "Can't reach the server";
    btn.style.display = "none";
  }
}
refreshAccount();
// The panel stays open while the user signs in elsewhere — re-check on focus.
window.addEventListener("focus", refreshAccount);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) refreshAccount();
});

// ── Microphone ───────────────────────────────────────────────────────────────
async function refreshMic() {
  try {
    const status = await navigator.permissions.query({ name: "microphone" });
    const granted = status.state === "granted";
    $("micd").textContent = granted ? "Hold ⌥ Option+S (Alt+S on Windows) anywhere to ask out loud." : "Needed once, for the whole extension.";
    $("micok").style.display = granted ? "" : "none";
    $("micbtn").style.display = granted ? "none" : "";
  } catch {
    $("micd").textContent = "Needed once, for the whole extension.";
    $("micbtn").style.display = "";
  }
}
$("micbtn").onclick = () => chrome.runtime.sendMessage({ type: "OPEN_MIC_SETUP" });
refreshMic();
window.addEventListener("focus", refreshMic);

// ── Voice answer model ───────────────────────────────────────────────────────
// The choice lives on the account (users.voiceChatModel server-side), so it
// follows the user across devices and matches the website's Settings page.
// GPT (gpt-4o-mini) is fastest; DeepSeek (deepseek-v4-flash) reasons more but
// answers a bit slower. Signed-out: the row shows a hint instead of the picker.
function renderVoiceModel(model) {
  for (const b of $("vmseg").querySelectorAll("button")) {
    b.classList.toggle("on", b.dataset.model === model);
  }
}

async function refreshVoiceModel() {
  const res = await chrome.runtime.sendMessage({ type: "VOICE_MODEL_GET" }).catch(() => null);
  if (res?.ok && res.data?.model) {
    $("vmseg").style.display = "";
    $("vmd").textContent = "Which AI answers when you ask out loud.";
    renderVoiceModel(res.data.model);
  } else {
    $("vmseg").style.display = "none";
    $("vmd").textContent = "Sign in to choose which AI answers out loud.";
  }
}

for (const b of $("vmseg").querySelectorAll("button")) {
  b.onclick = async () => {
    if (b.classList.contains("on")) return;
    const buttons = $("vmseg").querySelectorAll("button");
    buttons.forEach((x) => (x.disabled = true));
    const res = await chrome.runtime
      .sendMessage({ type: "VOICE_MODEL_SET", model: b.dataset.model })
      .catch(() => null);
    buttons.forEach((x) => (x.disabled = false));
    if (res?.ok) renderVoiceModel(b.dataset.model);
    else $("vmd").textContent = "Couldn't save — check your connection.";
  };
}

refreshVoiceModel();
window.addEventListener("focus", refreshVoiceModel);

// ── Card text size: ±2px steps, applied by the cards as a zoom factor ────────
const FONT_MIN = -4;
const FONT_MAX = 8;

function renderFont(delta) {
  $("f-out").textContent = delta === 0 ? "Default" : `${delta > 0 ? "+" : ""}${delta} px`;
  $("f-minus").disabled = delta <= FONT_MIN;
  $("f-plus").disabled = delta >= FONT_MAX;
}

async function nudgeFont(step) {
  const { fontDelta = 0 } = await chrome.storage.local.get("fontDelta");
  const next = Math.max(FONT_MIN, Math.min(FONT_MAX, fontDelta + step));
  await chrome.storage.local.set({ fontDelta: next });
  renderFont(next);
}

$("f-minus").onclick = () => nudgeFont(-2);
$("f-plus").onclick = () => nudgeFont(2);
chrome.storage.local.get("fontDelta").then(({ fontDelta = 0 }) => renderFont(fontDelta));

// ── Prefetch ─────────────────────────────────────────────────────────────────
chrome.storage.local.get("prefetch").then(({ prefetch }) => {
  $("prefetch").checked = prefetch !== false;
});
$("prefetch").onchange = (e) => chrome.storage.local.set({ prefetch: e.target.checked });

// The dev-only server override UI is gone for the store build. background.js
// still honours an apiBase set by hand in chrome.storage (dev console), but
// nothing user-facing writes it, and the manifest only grants romaintalk.com.
