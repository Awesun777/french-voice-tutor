/**
 * keyhook.js — chord relay for frames the main content script never sees.
 *
 * Google Docs (and editors like it) capture typing inside a hidden subframe
 * and render the document to a canvas, so keystrokes never reach the top
 * frame where content.js listens — the shortcut wasn't being overruled, it
 * was never delivered. This script runs in every subframe (all_frames, with
 * match_origin_as_fallback for Docs' about:blank input frame), watches for
 * the two chords and nothing else, and relays them through the service worker
 * to the top frame, where the card lives. ~30 lines, no DOM, no fonts.
 */
(() => {
  if (window.top === window) return; // the top frame runs content.js itself

  /** True while a relayed hold is in progress, so keyups pair with keydowns. */
  let held = false;

  const relay = (payload) => {
    try {
      chrome.runtime.sendMessage({ type: "RELAY_KEY", ...payload });
    } catch { /* extension was reloaded; nothing to do from here */ }
  };

  document.addEventListener(
    "keydown",
    (e) => {
      if (!e.altKey || e.metaKey || e.ctrlKey || e.shiftKey) return;

      if (e.code === "KeyS") {
        // Swallow repeats too, or holding the chord in the editor would type
        // a stream of "ß" into the document while the mic records.
        if (e.repeat) { e.preventDefault(); return; }
        e.preventDefault();
        e.stopPropagation();
        held = true;
        relay({ chord: "voice-down" });
      } else if (e.code === "KeyD") {
        // A selection inside this frame travels along — the top frame can't
        // read another frame's selection.
        const selection = String(window.getSelection?.() ?? "").trim();
        if (!selection) return;
        e.preventDefault();
        e.stopPropagation();
        relay({ chord: "lookup", selection });
      }
    },
    true
  );

  document.addEventListener(
    "keyup",
    (e) => {
      if (!held) return;
      if (e.key !== "Alt" && e.code !== "KeyS") return;
      held = false;
      relay({ chord: "voice-up" });
    },
    true
  );

  // Losing the frame mid-hold must still end the recording.
  window.addEventListener("blur", () => {
    if (held) {
      held = false;
      relay({ chord: "voice-up" });
    }
  });
})();
