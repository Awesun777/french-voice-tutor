/**
 * content.js — selection capture, keyboard shortcuts and the on-page card.
 *
 * Runs in the page, so it can read the selection and the keystrokes, but it
 * never talks to the API directly (see background.js for why). Everything it
 * renders lives inside a shadow root, because Le Monde's stylesheet is not our
 * friend.
 *
 * The shortcuts are the website's, matched the same way Home.tsx matches them:
 *   Alt+D  look up the selection (also a chrome.commands binding)
 *   Alt+S  hold to ask a question out loud, release to send
 */

(() => {
  // The manifest injects this at document_idle, and background.js may inject it
  // again on tabs that predate the install. Bail on the second run.
  if (window.__romainLookupLoaded) return;
  window.__romainLookupLoaded = true;

  const MAX_TERM = 300; // matches dictionary.search's input cap

  /**
   * Set on the tutor's own site, where the extension stands down completely:
   * the website has its own lookup and voice shortcuts, and without this
   * both would fire and open two panels over each other. The website wins.
   *
   * The manifest's `exclude_matches` already keeps this file out of
   * romaintalk.com, so this only catches a custom API endpoint set in the popup
   * for local development — but a silent double-panel is a miserable bug, and
   * the check costs nothing.
   */
  let standDown = false;

  /** Never throws: a missing storage API just yields the fallback. */
  async function readSetting(key, fallback) {
    try {
      const got = await chrome.storage.local.get(key);
      return got[key] === undefined ? fallback : got[key];
    } catch {
      return fallback;
    }
  }

  void (async () => {
    const base = await readSetting("apiBase", "https://romaintalk.com");
    try {
      if (new URL(base).origin === location.origin) standDown = true;
    } catch { /* malformed setting — stay active */ }
  })();

  // ─── Page context ──────────────────────────────────────────────────────────

  /**
   * The sentence the selection sits in — this is what turns "define this word"
   * into "explain this word *here*", which is the whole reason to look things
   * up while reading rather than in a dictionary tab.
   */
  function surroundingSentence(selection, term) {
    try {
      const node = selection.anchorNode;
      if (!node) return "";
      const block =
        (node.nodeType === Node.TEXT_NODE ? node.parentElement : node)?.closest(
          "p, li, blockquote, h1, h2, h3, figcaption, td, dd, article, section"
        ) || node.parentElement;
      if (!block) return "";

      const text = block.textContent.replace(/\s+/g, " ").trim();
      if (text.length <= 400) return text;

      const at = text.indexOf(term);
      if (at === -1) return text.slice(0, 400);

      // Widen to sentence boundaries around the hit, then hard-cap.
      const before = text.slice(0, at);
      const after = text.slice(at + term.length);
      const start = Math.max(before.lastIndexOf(". "), before.lastIndexOf("! "), before.lastIndexOf("? "));
      const endRel = after.search(/[.!?…]\s/);
      const sentence =
        text.slice(start === -1 ? 0 : start + 2, at + term.length + (endRel === -1 ? after.length : endRel + 1));
      return sentence.trim().slice(0, 400);
    } catch {
      return "";
    }
  }

  function pageSource() {
    // Prefer the publication's own name over a bare hostname — "Le Monde" reads
    // better than "lemonde.fr" when this shows up in the library weeks later.
    const site =
      document.querySelector('meta[property="og:site_name"]')?.content?.trim() ||
      document.querySelector('meta[name="application-name"]')?.content?.trim() ||
      "";
    const host = location.hostname.replace(/^www\./, "");
    return site && site.toLowerCase() !== host.toLowerCase() ? `${site} · ${host}` : host;
  }

  function currentSelection(fallback) {
    const sel = window.getSelection();
    const raw = (sel?.toString() || fallback || "").replace(/\s+/g, " ").trim();
    if (!raw) return null;
    const term = raw.slice(0, MAX_TERM);
    let rect = null;
    try {
      if (sel && sel.rangeCount) rect = sel.getRangeAt(0).getBoundingClientRect();
    } catch { /* detached range */ }
    return {
      term,
      rect: rect && rect.width + rect.height > 0 ? rect : null,
      sentence: sel ? surroundingSentence(sel, term) : "",
      source: pageSource(),
      title: document.title,
    };
  }


  // ─── Brand fonts ───────────────────────────────────────────────────────────

  /**
   * Roboto (display — questions, headwords) and Nunito Sans (text), the
   * website's own pairing, bundled with the extension.
   *
   * Loaded through the FontFace API from fetched bytes rather than @font-face,
   * because @font-face URLs inside a content script are subject to the *page's*
   * CSP — a news site with font-src 'self' would silently block them. Bytes
   * handed directly to FontFace bypass font-src entirely. Families are
   * namespaced ("Romain …") so a page's own Roboto registration can't collide.
   * Variable-font files cover the whole weight range in one download.
   */
  const FONTS = [
    {
      "file": "nunitoi-latin-ext.woff2",
      "family": "Romain Nunito",
      "weight": "400",
      "style": "italic",
      "range": "U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF"
    },
    {
      "file": "nunitoi-latin.woff2",
      "family": "Romain Nunito",
      "weight": "400",
      "style": "italic",
      "range": "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD"
    },
    {
      "file": "nunito-latin-ext.woff2",
      "family": "Romain Nunito",
      "weight": "400 700",
      "style": "normal",
      "range": "U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF"
    },
    {
      "file": "nunito-latin.woff2",
      "family": "Romain Nunito",
      "weight": "400 700",
      "style": "normal",
      "range": "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD"
    },
    {
      "file": "roboto-latin-ext.woff2",
      "family": "Romain Roboto",
      "weight": "500 700",
      "style": "normal",
      "range": "U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF"
    },
    {
      "file": "roboto-latin.woff2",
      "family": "Romain Roboto",
      "weight": "500 700",
      "style": "normal",
      "range": "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD"
    }
  ];

  /**
   * User text-size preference from the side panel, stored as a ±px delta and
   * applied as a zoom factor on the card — one knob that scales type and
   * spacing together instead of re-plumbing every px value in the stylesheet.
   */
  let fontZoom = 1;
  void (async () => {
    const delta = await readSetting("fontDelta", 0);
    fontZoom = (14 + Number(delta || 0)) / 14;
  })();
  try {
    chrome.storage?.onChanged?.addListener((changes, area) => {
      if (area === "local" && changes.fontDelta) {
        fontZoom = (14 + Number(changes.fontDelta.newValue || 0)) / 14;
        const el = root?.querySelector(".card");
        if (el) el.style.zoom = fontZoom;
      }
    });
  } catch { /* no storage events in the dev harness */ }

  let fontsRequested = false;
  function ensureFonts() {
    if (fontsRequested) return;
    fontsRequested = true;
    for (const f of FONTS) {
      fetch(chrome.runtime.getURL(`fonts/${f.file}`))
        .then((r) => r.arrayBuffer())
        .then((buf) => {
          const face = new FontFace(f.family, buf, {
            weight: f.weight,
            style: f.style,
            unicodeRange: f.range,
          });
          document.fonts.add(face);
        })
        .catch(() => { /* fallback stacks cover it */ });
    }
  }

  // ─── Card shell ────────────────────────────────────────────────────────────

  let host = null;
  let root = null;
  let ctx = null; // the selection this card was opened for
  let lastResult = null;
  let requestSeq = 0; // guards against out-of-order lookup replies

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; margin: 0; padding: 0; }

    /* ── Romain's "warm cream French" palette, ported from the website ──────
       cream #FFF8ED · white cards · navy #173F6B · charcoal #252321
       burgundy #A63D4A (speaking) · rose mist #F4E0E3 (speaking surface)
       pale blue #DCECF8 · border blue #CBD9E6 · muted gray #6F6A64
       The website is light-only, so the extension is too — a themed card on a
       dark page still reads as Romain, not as a mismatched widget. */

    .card {
      position: fixed;
      z-index: 2147483647;
      width: 372px;
      max-height: min(70vh, 620px);
      display: flex;
      flex-direction: column;
      font-family: "Romain Nunito", "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      font-size: 14px;
      line-height: 1.5;
      color: #252321;
      background: #ffffff;
      border: 1px solid #E7DFD2;
      border-radius: 20px;
      box-shadow: 0 24px 60px -12px rgba(23, 63, 107, .35), 0 2px 8px rgba(23, 63, 107, .08);
      overflow: hidden;
      animation: pop .12s ease-out;
    }
    @keyframes pop { from { opacity: 0; transform: translateY(-4px); } }
    .icon-btn {
      border: 0; background: transparent; cursor: pointer; padding: 3px 6px;
      border-radius: 6px; font-size: 13px; line-height: 1; color: #6F6A64;
    }
    .icon-btn:hover { background: #DCECF8; color: #173F6B; }
    .dbody { padding: 8px 10px 12px; overflow-y: auto; flex: 1; }
    /* The headword box doubles as the drag handle. */
    /* Clickable brand wordmark, bottom-left of both cards → opens the website. */
    .brand-logo {
      height: 20px; width: auto; cursor: pointer; flex: none; display: block;
      padding: 4px 7px; border-radius: 8px; box-sizing: content-box;
      transition: background .12s ease, transform .12s ease, box-shadow .12s ease;
    }
    .brand-logo:hover {
      background: #DCECF8;
      transform: translateY(-1px);
      box-shadow: 0 3px 8px rgba(23, 63, 107, .18);
    }
    .brandfoot { display: flex; align-items: center; padding: 2px 12px 10px; flex: none; }
    /* Flat dictionary header, no box: word first, ▶ beside it, pronunciation,
       then the remaining controls pushed to the window's right edge — one row,
       all centred on the word. Doubles as the drag handle. */
    .dhead { display: flex; align-items: center; gap: 8px; cursor: grab; user-select: none; margin: 2px 2px 10px; }
    .dhead.dragging { cursor: grabbing; }
    .dhead .qactions { position: static; flex: none; margin-left: auto; }
    .dhead .pron { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .dterm {
      font-family: "Romain Nunito", "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      font-weight: 700; font-size: 15px; line-height: 1.45; color: #173F6B;
      min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    /* Save: + until pressed, then a green circled tick that stays. */
    .addbtn {
      border: 0; cursor: pointer; width: 25px; height: 25px; border-radius: 50%;
      background: #DCECF8; color: #173F6B; font-size: 16px; font-weight: 700; line-height: 1;
      display: inline-flex; align-items: center; justify-content: center; flex: none;
    }
    .addbtn:hover:not(:disabled) { background: #C9DFF2; }
    .addbtn.saved { background: #2F9E44; color: #fff; font-size: 12px; }
    .addbtn:disabled { cursor: default; }

    /* ── Meaning first ────────────────────────────────────────────────────── */
    .term { font-size: 20px; font-weight: 700; letter-spacing: -.01em; color: #173F6B; font-family: "Romain Nunito", "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif; }
    .term-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    /* Pronunciation is burgundy everywhere on the website — same role here. */
    .say {
      border: 0; background: #F4E0E3; cursor: pointer; width: 25px; height: 25px;
      border-radius: 50%; font-size: 11px; line-height: 1; color: #A63D4A;
      display: inline-flex; align-items: center; justify-content: center; flex: none;
    }
    .say:hover { background: #EFCDD2; }
    .say[data-state="loading"] { opacity: .5; cursor: default; }
    .say[data-state="playing"] { background: #A63D4A; color: #fff; }
    .pron { font-size: 13px; color: #6F6A64; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
    /* accent-strong: the website's darkened friendly-blue for text that must
       read as blue and still pass contrast on light surfaces. */
    .translation { font-size: 16px; color: #22648C; margin-top: 4px; padding-left: 2px; font-weight: 600; line-height: 1.35; }
    .tags { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 9px; }
    .tag {
      font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 999px;
      background: #DCECF8; color: #173F6B;
    }
    .tag.f { background: #F4E0E3; color: #A63D4A; }
    .tag.m { background: #DCECF8; color: #173F6B; }

    /* ── Folds ────────────────────────────────────────────────────────────── */
    .folds { margin-top: 12px; border-top: 1px solid #EFE2CE; }
    details { border-bottom: 1px solid #EFE2CE; }
    summary {
      list-style: none; cursor: pointer; padding: 7px 0;
      display: flex; align-items: center; gap: 6px;
      font-size: 12px; font-weight: 700; color: #6F6A64;
    }
    summary::-webkit-details-marker { display: none; }
    summary::before {
      content: "›"; font-size: 14px; line-height: 1; color: #C9BFAE;
      transition: transform .12s ease; display: inline-block;
    }
    details[open] > summary::before { transform: rotate(90deg); }
    summary .count { color: #B4A98F; font-weight: 600; }
    .fold-body { padding: 2px 0 10px 14px; }
    .fold-body.pending { color: #B4A98F; font-size: 13px; }

    .ex { margin-bottom: 8px; }
    .ex:last-child { margin-bottom: 0; }
    .ex .fr { font-style: italic; }
    .ex .en { color: #6F6A64; font-size: 13px; }
    .conj { display: grid; grid-template-columns: repeat(2, 1fr); gap: 3px 12px; font-size: 12.5px; }
    .conj span { color: #4A4640; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .chips { display: flex; flex-wrap: wrap; gap: 5px; }
    .chip { font-size: 12px; background: #DCECF8; color: #173F6B; border-radius: 7px; padding: 2px 8px; }
    .note { font-size: 13px; color: #252321; margin-bottom: 7px; }
    .note:last-child { margin-bottom: 0; }
    .ctxnote { margin-top: 8px; font-size: 13px; }
    .ctxnote:first-child { margin-top: 0; }
    .note b { color: #173F6B; }

    /* ── Footer ───────────────────────────────────────────────────────────── */
    .foot { border-top: 1px solid #EFE2CE; padding: 10px 14px 12px; background: #FFF8ED; }
    .actions { display: flex; gap: 7px; }
    .btn {
      flex: 1; border: 1px solid #CBD9E6; background: #fff; color: #252321;
      font: inherit; font-size: 13px; font-weight: 700; padding: 7px 10px;
      border-radius: 10px; cursor: pointer; display: flex; align-items: center;
      justify-content: center; gap: 5px;
    }
    .btn:hover:not(:disabled) { background: #DCECF8; border-color: #A9C6DE; }
    .btn:disabled { opacity: .55; cursor: default; }
    .btn.primary { background: #173F6B; border-color: #173F6B; color: #FFF8ED; }
    .btn.primary:hover:not(:disabled) { background: #2E527A; }
    .btn.done { background: #E5F0E8; border-color: #A9C9B4; color: #2F5E3F; }
    .ask { display: flex; gap: 6px; margin-top: 8px; }
    .ask input {
      flex: 1; font: inherit; font-size: 13px; padding: 7px 10px;
      border: 1px solid #CBD9E6; border-radius: 10px; background: #fff; color: #252321; min-width: 0;
    }
    .ask input:focus { outline: 2px solid #173F6B; outline-offset: -1px; }
    .ask button { border: 0; background: #173F6B; color: #FFF8ED; border-radius: 10px; padding: 0 13px; cursor: pointer; font: inherit; font-size: 13px; font-weight: 700; }
    .reply {
      margin-top: 9px; padding: 9px 11px; background: #fff; border: 1px solid #E7DFD2;
      border-radius: 10px; font-size: 13px; white-space: pre-wrap; max-height: 190px; overflow-y: auto;
    }
    .hint { font-size: 11px; color: #A79F8F; margin-top: 7px; text-align: center; }
    .hint kbd {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 10px;
      background: #fff; border: 1px solid #E5D9C2; border-radius: 4px; padding: 1px 4px;
    }

    .muted { color: #6F6A64; font-size: 13px; }
    .center { text-align: center; padding: 22px 10px; }
    .spinner {
      width: 17px; height: 17px; border: 2px solid #DCECF8; border-top-color: #173F6B;
      border-radius: 50%; animation: spin .7s linear infinite; margin: 0 auto 9px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .err { color: #C0392B; }

    /* ── Voice — a dictation pill that expands on release ─────────────────── */
    .card.voice {
      background: #FFF8ED; color: #252321;
      border: 1px solid rgba(23, 63, 107, .08);
      border-radius: 999px;
      box-shadow: 0 20px 55px -10px rgba(23, 63, 107, .4), 0 3px 10px rgba(23, 63, 107, .1);
      transition:
        width .3s cubic-bezier(.2, .8, .2, 1),
        left .3s cubic-bezier(.2, .8, .2, 1),
        max-height .34s cubic-bezier(.2, .8, .2, 1),
        border-radius .3s ease;
    }
    .card.voice.pill { max-height: 54px; }
    /* Expanded, the card becomes a piece of the website: cream page surface
       with white cards hovering on it under navy-tinted shadows. */
    .card.voice.expanded { border-radius: 20px; max-height: min(60vh, 520px); background: #ffffff; }
    .wave { display: flex; align-items: center; justify-content: center; gap: 3px; height: 54px; width: 100%; flex: none; }
    /* Burgundy — the website's speaking colour, so the pill reads as Romain. */
    .wave span {
      flex: none; width: 3px; height: 4px; border-radius: 2px;
      background: #A63D4A; transition: height .1s ease-out;
    }
    .wave:not(.live) span { animation: wv 1.5s ease-in-out infinite; }
    @keyframes wv { 0%, 100% { height: 4px; } 50% { height: 15px; } }
    .vhead { display: flex; justify-content: flex-end; align-items: center; gap: 7px; margin-bottom: 8px; }
    .vclose {
      border: 0; background: transparent; color: #6F6A64; cursor: pointer;
      font-size: 14px; line-height: 1; padding: 4px 6px; border-radius: 6px;
    }
    .vclose:hover { color: #252321; background: #F4E0E3; }
    .vbody { padding: 8px 10px 14px; overflow-y: auto; width: 100%; }
    /* The question card: white, floating on the cream body under the site's
       navy shadow, with the gentle lift-on-hover the website's cards have.
       Context on top in the speaking colour; the question beneath, black and a
       step smaller; the controls live inside the card's top-right corner. */
    .qbox {
      position: relative;
      background: #FFF8ED;
      border: 1px solid #EFE2CE;
      border-radius: 16px;
      padding: 13px 15px;
      box-shadow: 0 12px 32px -10px rgba(23, 63, 107, .3), 0 2px 6px rgba(23, 63, 107, .08);
      transition: transform .15s ease, box-shadow .15s ease;
    }
    .qbox:hover {
      transform: translateY(-1px);
      box-shadow: 0 16px 40px -10px rgba(23, 63, 107, .36), 0 3px 8px rgba(23, 63, 107, .1);
    }
    .qactions { position: absolute; top: 10px; right: 10px; display: flex; align-items: center; gap: 6px; }
    .qctx {
      font-family: "Romain Nunito", "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      font-weight: 700; font-size: 15px; color: #A63D4A;
      padding-right: 70px; line-height: 1.4;
      overflow: hidden; text-overflow: ellipsis;
    }
    .qa-q { font-family: "Romain Nunito", "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif; font-weight: 500; font-size: 13.5px; line-height: 1.5; color: #252321; margin-top: 4px; }
    /* Without a highlighted context the question takes the top slot. */
    .qa-q.lone { font-weight: 700; font-size: 15px; margin-top: 0; padding-right: 70px; }
    /* Siri-style thinking dots between transcript and answer. */
    .dots { display: inline-flex; gap: 4px; margin: 14px 0 2px 3px; align-items: center; }
    .dots span { width: 6px; height: 6px; border-radius: 50%; background: #A63D4A; animation: dot 1.2s ease-in-out infinite; }
    .dots span:nth-child(2) { animation-delay: .15s; }
    .dots span:nth-child(3) { animation-delay: .3s; }
    @keyframes dot { 0%, 100% { opacity: .25; transform: translateY(0); } 40% { opacity: 1; transform: translateY(-2px); } }
    .ctx-chip {
      display: inline-block; font-size: 12px; font-style: italic;
      background: #F4E0E3; color: #A63D4A; border-radius: 7px; padding: 2px 8px; margin-top: 8px;
      max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .vreply { margin-top: 14px; font-size: 14.5px; line-height: 1.65; color: #252321; text-align: left; }
    /* Writing helper: the paste-ready phrase, visually the "result" row. */
    .copyrow {
      display: flex; align-items: center; gap: 10px; margin-top: 12px;
      background: #DCECF8; border-radius: 12px; padding: 9px 13px;
    }
    .copyphrase {
      flex: 1; min-width: 0; font-weight: 700; font-size: 15px; color: #173F6B;
      font-family: "Romain Roboto", Roboto, "Segoe UI", system-ui, sans-serif;
    }
    .copied { flex: none; font-size: 12px; font-weight: 700; color: #2F9E44; }
    .copybtn {
      flex: none; border: 0; background: #173F6B; color: #FFF8ED; cursor: pointer;
      font: inherit; font-size: 12px; font-weight: 700; padding: 5px 11px; border-radius: 8px;
    }
    .copybtn:hover { background: #2E527A; }
    .vfoot { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 14px; }
    .vlink {
      border: 0; background: transparent; color: #173F6B; cursor: pointer;
      font: inherit; font-size: 13px; font-weight: 700; padding: 0;
    }
    .vlink:hover { text-decoration: underline; }
    .vnote { font-size: 11px; color: #6F6A64; }

    /* ── Rendered tutor Markdown ──────────────────────────────────────────── */
    .md p { margin: 0 0 8px; }
    .md ul, .md ol { margin: 0 0 8px; padding-left: 18px; }
    .md li { margin-bottom: 4px; }
    .md li:last-child { margin-bottom: 0; }
    .md p:last-child, .md ul:last-child, .md ol:last-child { margin-bottom: 0; }
    .md strong { font-weight: 700; color: #173F6B; }
    .md code {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12.5px;
      background: #FFF8ED; border: 1px solid #EFE2CE; border-radius: 5px; padding: 0 4px;
    }
    .md .lbl {
      font-size: 10.5px; font-weight: 800; letter-spacing: .07em; text-transform: uppercase;
      color: #6F6A64; margin: 10px 0 4px;
    }
    .md .lbl:first-child { margin-top: 0; }
    /* French quotes carry the speaking colour, same role as on the website. */
    .md .frq { color: #A63D4A; font-style: italic; }
    .md .mdhr { border: 0; border-top: 1px solid #EFE2CE; margin: 10px 0; }
    .md blockquote { border-left: 3px solid #DCECF8; padding: 2px 0 2px 10px; margin: 0 0 8px; color: #4A4640; }
    .md blockquote:last-child { margin-bottom: 0; }
    .md .mdt { border-collapse: collapse; margin: 0 0 8px; font-size: 13px; width: 100%; }
    .md .mdt th, .md .mdt td { border: 1px solid #EFE2CE; padding: 4px 9px; text-align: left; vertical-align: top; }
    .md .mdt th { background: #FFF8ED; font-weight: 700; color: #173F6B; }
    .md ul ul { margin: 4px 0 0; padding-left: 16px; }
  `;

  function ensureCard() {
    ensureFonts();
    if (host && document.documentElement.contains(host)) return;
    host = document.createElement("div");
    host.id = "romain-lookup-host";
    // The host itself must be inert: no size, no layout impact. The card inside
    // is position:fixed, so it escapes this box entirely.
    host.style.cssText = "all: initial; position: absolute; top: 0; left: 0; width: 0; height: 0;";
    root = host.attachShadow({ mode: "open" });

    // adoptedStyleSheets first: a constructed sheet is never a DOM <style>, so
    // a page with a strict style-src CSP can't interfere with it.
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(CSS);
      root.adoptedStyleSheets = [sheet];
    } catch {
      const style = document.createElement("style");
      style.textContent = CSS;
      root.appendChild(style);
    }

    const el = document.createElement("div");
    el.className = "card";
    el.style.display = "none";
    el.style.zoom = fontZoom;
    root.appendChild(el);

    // documentElement, not body: a `position: fixed` descendant of any element
    // with a transform/filter/perspective anchors to that element instead of the
    // viewport, and plenty of news sites transform their body wrapper.
    document.documentElement.appendChild(host);
    wireDrag(el);
  }

  const card = () => root.querySelector(".card");

  const CARD_W = 480;
  const MARGIN = 10;

  function place(rect) {
    const el = card();
    el.style.display = "flex";

    if (!rect) {
      el.style.left = `${Math.max(MARGIN, window.innerWidth - CARD_W - 24)}px`;
      el.style.top = "72px";
      el.style.bottom = "auto";
      return;
    }

    el.style.left = `${Math.min(Math.max(MARGIN, rect.left), Math.max(MARGIN, window.innerWidth - CARD_W * fontZoom - MARGIN))}px`;

    // Anchor below the selection when there's room, otherwise pin the card's
    // bottom just above it. Anchoring by `bottom` means we don't have to guess
    // the height of content that hasn't rendered yet.
    const below = window.innerHeight - rect.bottom;
    if (below > 300 || below >= rect.top) {
      el.style.top = `${rect.bottom + 8}px`;
      el.style.bottom = "auto";
    } else {
      el.style.top = "auto";
      el.style.bottom = `${window.innerHeight - rect.top + 8}px`;
    }
  }

  /**
   * Bottom-centred at an explicit width. The pill and the expanded answer use
   * different widths, and since both set inline `width` and `left`, the CSS
   * transition animates the morph between them.
   */
  function centerVoice(width) {
    const el = card();
    el.style.display = "flex";
    el.style.width = `${width}px`;
    el.style.left = `${Math.max(MARGIN, (window.innerWidth - width * fontZoom) / 2)}px`;
    el.style.top = "auto";
    el.style.bottom = "36px";
  }

  function close() {
    if (root) card().style.display = "none";
    lastResult = null;
    sayText = null;
    stopAudio();
    // Dismissing mid-hold has to release the mic, or it records on unheard.
    if (voiceOpen) {
      voiceOpen = false;
      voiceStopped = true;
      send({ type: "VOICE_ABORT" });
    }
  }

  // Registered once for the page, not once per card, so re-creating the host
  // (if a framework wipes documentElement's children) can't stack duplicates.
  const isOpen = () => root && card()?.style.display !== "none";

  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key === "Escape" && isOpen()) close();
    },
    true
  );

  document.addEventListener(
    "mousedown",
    (e) => {
      if (!isOpen()) return;
      // Clicks inside a shadow root are retargeted to the host element.
      if (e.composedPath().includes(host)) return;
      close();
    },
    true
  );

  function wireDrag(el) {
    let sx = 0, sy = 0, ox = 0, oy = 0, dragging = false;

    el.addEventListener("mousedown", (e) => {
      const path = e.composedPath();
      const handle = path.find((n) => n.classList?.contains("dhead"));
      if (!handle || path.some((n) => n.classList?.contains("icon-btn") || n.classList?.contains("say") || n.classList?.contains("vclose"))) return;
      dragging = true;
      handle.classList.add("dragging");
      sx = e.clientX;
      sy = e.clientY;
      // The card may currently be anchored by `bottom`; convert to top/left off
      // its real box so the drag maths has a consistent origin.
      const box = el.getBoundingClientRect();
      ox = box.left;
      oy = box.top;
      el.style.bottom = "auto";
      el.style.top = `${oy}px`;
      el.style.left = `${ox}px`;
      e.preventDefault();
    });

    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      el.style.left = `${ox + e.clientX - sx}px`;
      el.style.top = `${oy + e.clientY - sy}px`;
    });

    window.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;
      root?.querySelector(".dhead")?.classList.remove("dragging");
    });
  }

  // ─── Pronunciation ─────────────────────────────────────────────────────────

  let currentAudio = null;

  function stopAudio() {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.src = "";
      currentAudio = null;
    }
  }

  function b64ToBlobUrl(base64, mimeType) {
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return URL.createObjectURL(new Blob([bytes], { type: mimeType || "audio/mpeg" }));
  }

  /** text → blob URL, so replaying a word costs nothing. */
  const audioCache = new Map();
  let audioPending = null;
  /**
   * The exact string the audio was fetched for. Kept separately because the
   * headword we pronounce is the lemma (`baseForm`), which is not always the
   * string `savableFrom` yields — a cache key mismatch would silently downgrade
   * every playback to the local voice.
   */
  let sayText = null;

  /**
   * Fetches the audio without playing it. Fired as soon as a word result lands
   * so that pressing 🔊 is instant rather than a second round trip.
   */
  async function preloadAudio(text) {
    if (!text || audioCache.has(text)) return;
    audioPending = text;
    setSayState("loading");
    const res = await send({ type: "TTS", text });
    if (res.ok && res.data?.base64) {
      audioCache.set(text, b64ToBlobUrl(res.data.base64, res.data.mimeType));
      if (audioPending === text) setSayState("idle");
    } else if (audioPending === text) {
      // Leave the button usable — speak() falls back to the local voice.
      setSayState("idle");
    }
    if (audioPending === text) audioPending = null;
  }

  function setSayState(state) {
    const btn = root?.querySelector(".say");
    if (btn) btn.dataset.state = state;
  }

  function speak(text) {
    if (!text) return;
    stopAudio();
    const url = audioCache.get(text);
    if (url) {
      currentAudio = new Audio(url);
      setSayState("playing");
      currentAudio.onended = () => setSayState("idle");
      currentAudio.onerror = () => setSayState("idle");
      currentAudio.play().catch(() => setSayState("idle"));
      return;
    }
    // Not loaded yet (or TTS failed) — the local voice is worse at French but
    // beats silence while the good audio is still in flight.
    if (window.speechSynthesis) {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "fr-FR";
      u.rate = 0.9;
      const fr = speechSynthesis.getVoices?.().find((v) => v.lang?.toLowerCase().startsWith("fr"));
      if (fr) u.voice = fr;
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
    }
  }

  // ─── Rendering ─────────────────────────────────────────────────────────────

  const esc = (s) =>
    String(s ?? "").replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
    );

  /**
   * The tutor answers in Markdown — the endpoint has no formatting constraint,
   * and Tutor Chat renders it through Streamdown, so the model has learned it
   * can. Shown raw it's asterisk soup. This renders the safe subset the tutor
   * actually emits: bold, italics, bullet/numbered lists, headings, code —
   * plus « … » quotes styled in the speaking colour.
   *
   * XSS-safe by construction: every line passes through esc() before any tags
   * are added, so the only HTML in the output is ours.
   */
  function renderMarkdown(text) {
    const inline = (str) => {
      let t = esc(str);
      t = t.replace(/`([^`]+)`/g, "<code>$1</code>");
      t = t.replace(/\*\*\*([^*]+)\*\*\*/g, "<strong><em>$1</em></strong>");
      t = t.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
      t = t.replace(/__([^_]+)__/g, "<strong>$1</strong>");
      t = t.replace(/(^|[^\w*])\*([^*\s][^*]*?)\*(?=[^\w*]|$)/g, "$1<em>$2</em>");
      t = t.replace(/(^|[^\w_])_([^_\s][^_]*?)_(?=[^\w_]|$)/g, "$1<em>$2</em>");
      t = t.replace(/«\s?([^»\n]+?)\s?»/g, '<span class="frq">«&nbsp;$1&nbsp;»</span>');
      return t;
    };

    const out = [];
    let para = [];
    let list = null; // { tag, items: [{ text, sub: [] }] }
    let table = null; // rows of cell arrays
    let quote = [];

    const flushPara = () => {
      if (para.length) out.push(`<p>${para.map(inline).join("<br>")}</p>`);
      para = [];
    };
    const flushList = () => {
      if (!list) return;
      out.push(`<${list.tag}>${list.items
        .map((i) => `<li>${inline(i.text)}${i.sub.length ? `<ul>${i.sub.map((x) => `<li>${inline(x)}</li>`).join("")}</ul>` : ""}</li>`)
        .join("")}</${list.tag}>`);
      list = null;
    };
    const flushTable = () => {
      if (!table) return;
      const [head, ...rows] = table;
      out.push(`<table class="mdt"><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>${rows
        .map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`)
        .join("")}</tbody></table>`);
      table = null;
    };
    const flushQuote = () => {
      if (quote.length) out.push(`<blockquote>${quote.map(inline).join("<br>")}</blockquote>`);
      quote = [];
    };
    const flushAll = () => { flushPara(); flushList(); flushTable(); flushQuote(); };

    for (const raw of String(text ?? "").replace(/\r/g, "").split("\n")) {
      const line = raw.replace(/\s+$/, "");
      const trimmed = line.trim();
      if (!trimmed) { flushAll(); continue; }

      // Tables — | a | b | rows; the |---|---| separator row is dropped.
      if (/^\|.*\|$/.test(trimmed)) {
        flushPara(); flushList(); flushQuote();
        if (!/^\|[\s:|-]+\|$/.test(trimmed)) {
          const cells = trimmed.slice(1, -1).split("|").map((c) => c.trim());
          (table ??= []).push(cells);
        }
        continue;
      }
      flushTable();

      // A rule line — or the underline of a setext heading, in which case the
      // single pending paragraph line above it was actually the heading.
      if (/^(?:-{3,}|_{3,}|\*{3,}|={3,})$/.test(trimmed)) {
        if (para.length === 1) {
          const title = para.pop();
          flushAll();
          out.push(`<div class="lbl">${inline(title)}</div>`);
        } else {
          flushAll();
          out.push('<hr class="mdhr">');
        }
        continue;
      }

      const heading = trimmed.match(/^#{1,4}\s+(.*)/);
      // A line that is nothing but bold ("**Exemples :**") is a heading in
      // spirit, and the model writes them constantly.
      const boldLabel = !heading && trimmed.match(/^\*\*([^*]+)\*\*\s*:?\s*$/);
      if (heading || boldLabel) {
        flushAll();
        out.push(`<div class="lbl">${inline((heading || boldLabel)[1].replace(/:\s*$/, ""))}</div>`);
        continue;
      }

      const quoted = trimmed.match(/^>\s?(.*)/);
      if (quoted) {
        flushPara(); flushList();
        quote.push(quoted[1]);
        continue;
      }
      flushQuote();

      const bullet = trimmed.match(/^[-*•]\s+(.*)/);
      const numbered = trimmed.match(/^\d+[.)]\s+(.*)/);
      if (bullet || numbered) {
        flushPara();
        const item = (bullet || numbered)[1];
        // An indented marker under an open list is a sub-item of the last one.
        if (/^\s{2,}/.test(line) && list?.items.length) {
          list.items[list.items.length - 1].sub.push(item);
        } else {
          const tag = bullet ? "ul" : "ol";
          if (list?.tag !== tag) { flushList(); list = { tag, items: [] }; }
          list.items.push({ text: item, sub: [] });
        }
        continue;
      }
      flushList();
      para.push(trimmed);
    }
    flushAll();
    return out.join("");
  }

  /** Markdown stripped for TTS, so nobody has to hear "asterisk asterisk". */
  const plainText = (md) =>
    String(md ?? "")
      .replace(/^\|[\s:|-]+\|$/gm, "")
      .replace(/\|/g, " ")
      .replace(/^#{1,4}\s+/gm, "")
      .replace(/^>\s?/gm, "")
      .replace(/^\s*(?:[-*•]|\d+[.)])\s+/gm, "")
      .replace(/^(?:-{3,}|_{3,}|\*{3,}|={3,})\s*$/gm, "")
      .replace(/[*_`]/g, "")
      .replace(/\n{3,}/g, "\n\n")
      .trim();

  /**
   * Dictionary card layout, mirroring the voice card: the searched word floats
   * in a cream box with the site's shadow at the top (it is also the drag
   * handle), the content sits on white below it, controls live inside the box.
   */
  function shell(boxHtml, bodyHtml, footHtml = "") {
    // A previous voice session leaves pill/expanded classes and inline sizing
    // on the shared card element; a lookup must start from the plain card.
    const el = card();
    el.className = "card";
    el.style.width = "";
    el.style.maxHeight = "";
    el.innerHTML = `
      <div class="dbody">
        ${boxHtml}
        ${bodyHtml ? `<div class="dcontent">${bodyHtml}</div>` : ""}
      </div>
      ${footHtml ? `<div class="foot">${footHtml}</div>` : ""}
      <div class="brandfoot">
        <img class="brand-logo" data-act="open" src="${chrome.runtime.getURL("brand/wordmark.png")}" alt="RomainTalk" title="Open romaintalk.com" />
      </div>
    `;
    el.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", onAction));
  }

  /**
   * Flat dictionary header (the voice card keeps its floating box; this one
   * matches the original design): the word's own row, with save and close at
   * the window's right edge at the same height.
   */
  function dhead(innerHtml, { save = false, saved = false } = {}) {
    return `<div class="dhead">
        ${innerHtml}
        <div class="qactions">
          ${save ? `<button class="addbtn${saved ? " saved" : ""}" data-act="save" ${saved ? "disabled" : ""} title="${saved ? "In your library" : "Save to library"}">${saved ? "✓" : "+"}</button>` : ""}
          <button class="vclose" data-act="close" title="Close (Esc)">✕</button>
        </div>
      </div>`;
  }

  function loading(term) {
    shell(
      dhead(`<span class="term">${esc(term)}</span>`),
      `<div class="center"><div class="spinner"></div><div class="muted">Looking up…</div></div>`
    );
  }

  function errorView(err) {
    if (err.code === "UNAUTHORIZED") {
      shell(
        dhead(`<span class="dterm">${esc(ctx?.term || "Romain")}</span>`),
        `<div class="center">
           <p style="font-weight:600;margin-bottom:5px">Not signed in</p>
           <p class="muted">Sign in at romaintalk.com and this works everywhere — it uses your normal session.</p>
         </div>`,
        `<div class="actions"><button class="btn primary" data-act="open">Sign in</button></div>`
      );
    } else {
      shell(
        dhead(`<span class="dterm">${esc(ctx?.term || "Romain")}</span>`),
        `<div class="center"><p class="err" style="font-weight:600;margin-bottom:5px">Lookup failed</p>
         <p class="muted">${esc(err.message)}</p></div>`,
        `<div class="actions"><button class="btn" data-act="retry">Try again</button></div>`
      );
    }
  }

  /** One collapsible section. Everything below the meaning is one of these. */
  function fold(title, count, innerHtml, { slot = "" } = {}) {
    if (!innerHtml && !slot) return "";
    return `
      <details${slot ? ` data-fold="${slot}"` : ""}>
        <summary>${esc(title)}${count ? ` <span class="count">${count}</span>` : ""}</summary>
        <div class="fold-body">${innerHtml}</div>
      </details>`;
  }

  const exampleList = (examples) =>
    (examples || [])
      .map((e) => `<div class="ex"><div class="fr">${esc(e.fr)}</div><div class="en">${esc(e.en)}</div></div>`)
      .join("");

  function footer(_opts = {}) {
    return `
      <div class="actions">
        <button class="btn" data-act="open">Library ↗</button>
      </div>
      <div class="ask">
        <input type="text" data-ask placeholder="Ask about this in context…" />
        <button data-act="ask">Ask</button>
      </div>
      <div data-reply></div>
      <div class="hint">Hold <kbd>Alt</kbd>+<kbd>S</kbd> to ask out loud</div>
    `;
  }

  /**
   * Meaning first. `r` may be a meaning-only entry — headword, translation,
   * part of speech, gender and nothing else — so every fold is rendered as an
   * empty slot up front and filled (or removed) as the later stages land. That
   * keeps the layout from jumping and lets the card paint on a response that is
   * a tenth the size of a full one.
   */
  function renderWord(r, alreadySaved) {
    const genderTag =
      r.gender === "feminine" ? '<span class="tag f">féminin</span>'
      : r.gender === "masculine" ? '<span class="tag m">masculin</span>'
      : r.gender === "both" ? '<span class="tag">m/f</span>' : "";

    shell(
      dhead(
        `<span class="term">${esc(r.word)}</span>
         <button class="say" data-act="speak" data-state="idle" title="Pronounce">▶</button>
         <span class="pron" data-pron>${r.pronunciation ? `[${esc(r.pronunciation)}]` : ""}</span>`,
        { save: true, saved: alreadySaved }
      ),
      `<div class="translation">${esc(r.translation)}</div>
       <div class="tags" data-tags>
         ${r.wordType ? `<span class="tag">${esc(r.wordType)}</span>` : ""}
         ${genderTag}
       </div>
       <div class="folds">
         ${fold("In this context", "", "", { slot: "notes" })}
         ${fold("Examples", "", "", { slot: "ex" })}
         ${fold("Conjugation", "", "", { slot: "conj" })}
         ${fold("Synonyms", "", "", { slot: "syn" })}
       </div>`
    );
    wireAskInput();

    root.querySelectorAll("[data-fold] .fold-body").forEach((b) => {
      b.className = "fold-body pending";
      b.textContent = "Loading…";
    });

    const headword = r.baseForm || r.word;
    sayText = headword;
    // Fire-and-forget so the audio is ready before the button is pressed.
    preloadAudio(headword);
  }

  /** Fills the folds that a "quick" (or cached full) entry can answer. */
  function fillFromRest(r) {
    const notes = [
      r.isConjugated && r.conjugationInfo
        ? `${esc(r.conjugationInfo)}${r.baseForm ? ` — base form <b>${esc(r.baseForm)}</b>` : ""}` : "",
      r.governedPreposition && r.prepositionExplanation ? esc(r.prepositionExplanation) : "",
      (r.isReflexive || r.hasReflexiveForm) && r.reflexiveExplanation ? esc(r.reflexiveExplanation) : "",
      r.adjectiveAuxiliary && r.adjectiveAuxiliaryExplanation ? esc(r.adjectiveAuxiliaryExplanation) : "",
    ].filter(Boolean);

    // The old notes, plus a slot the contextual analysis streams into. The
    // fold survives with either half; only both-empty removes it.
    const hasSentence = !!(ctx?.sentence && ctx.sentence.trim() && ctx.sentence.trim() !== ctx?.term?.trim());
    fillFold(
      "notes",
      "",
      notes.map((n) => `<div class="note">${n}</div>`).join("") +
        (hasSentence ? `<div data-ctxnote class="ctxnote"><span class="muted">Reading the sentence…</span></div>` : "")
    );
    fillFold("ex", (r.examples || []).length, exampleList(r.examples));

    // The meaning pass has no pronunciation; fill it in without a re-render.
    const pron = root.querySelector("[data-pron]");
    if (pron && !pron.textContent.trim() && r.pronunciation) pron.textContent = `[${r.pronunciation}]`;
    const tags = root.querySelector("[data-tags]");
    if (tags && r.governedPreposition) {
      tags.insertAdjacentHTML("beforeend", `<span class="tag">+ ${esc(r.governedPreposition)}</span>`);
    }
  }

  function renderPhrase(r, alreadySaved) {
    shell(
      dhead(
        `<span class="term">${esc(r.phrase)}</span>
         <button class="say" data-act="speak" data-state="idle" title="Pronounce">▶</button>`,
        { save: true, saved: alreadySaved }
      ),
      `<div class="translation">${esc(r.translation)}</div>
       <div class="folds">
         ${fold("Examples", (r.examples || []).length, exampleList(r.examples))}
         ${fold("Usage", "", r.usage ? `<div class="muted">${esc(r.usage)}</div>` : "")}
       </div>`
    );
    wireAskInput();
    sayText = r.phrase;
    preloadAudio(r.phrase);
  }

  function renderQuestion(r) {
    shell(
      dhead(`<span class="dterm">${esc(r.question)}</span>`),
      `<div class="sec">${esc(r.answer)}</div>
       <div class="folds">
         ${fold("Ways to say it", (r.options || []).length,
           (r.options || []).map((o) =>
             `<div class="ex"><div class="fr">${esc(o.french)}</div><div class="en">${esc(o.english)} — ${esc(o.summary)}</div></div>`
           ).join(""))}
       </div>`
    );
    wireAskInput();
  }

  /**
   * No dictionary entry — usually a proper noun: a person, a place, a brand,
   * a medicine (« le Leqembi »). Instead of shrugging, identify it: one short
   * plain-prose explanation of what the thing is, with the surrounding
   * sentence as a hint when there is one.
   */
  function renderNotFound(term, seq) {
    shell(
      dhead(`<span class="term">${esc(term)}</span>`),
      `<div data-whatis class="ctxnote"><span class="muted">Not in the dictionary — identifying…</span></div>
       <div class="hint" style="text-align:left;margin-top:10px">Hold <kbd>Alt</kbd>+<kbd>S</kbd> to ask more about it</div>`
    );
    void loadWhatIs(term, seq);
  }

  async function loadWhatIs(term, seq) {
    const sentence = ctx?.sentence && ctx.sentence.trim() !== term.trim() ? ctx.sentence : "";
    const res = await send({
      type: "ASK",
      message:
        `"${term}" has no French dictionary entry. In 1-2 short sentences of plain prose — no bullets — identify what it is (a person, a place, a brand, a company, a medicine, an acronym…) and what it refers to.${sentence ? ` It appeared in: "${sentence}".` : ""} If you genuinely don't recognize it, say it may be a typo or a very new term.`.slice(0, 2000),
    });
    const slot = root?.querySelector("[data-whatis]");
    if (seq !== requestSeq || !slot?.isConnected) return;
    slot.innerHTML = res.ok
      ? `<div class="md">${renderMarkdown(res.data?.reply)}</div>`
      : `<span class="muted">No dictionary entry — it may be a proper noun or a typo.</span>`;
  }

  const PERSONS = ["je", "tu", "il/elle", "nous", "vous", "ils/elles"];

  /**
   * Fills the three heavy folds. A cached "full" entry already carries them —
   * which is what the precompute script generates — so `inline` skips the
   * separate searchDetails call entirely whenever the data is already in hand.
   */
  async function loadDetails(word, seq, inline) {
    if (!word || !root.querySelector('[data-fold="conj"]')) return;
    const res = inline ? { ok: true, data: inline } : await send({ type: "LOOKUP_DETAILS", word });
    if (seq !== requestSeq || !root.querySelector('[data-fold="conj"]')) return;

    const d = res.ok ? res.data || {} : {};
    const present = d.conjugations?.present || [];

    fillFold("conj", present.length,
      present.length
        ? `<div class="conj">${present.map((f, i) => `<span>${esc(PERSONS[i] || "")} ${esc(f)}</span>`).join("")}</div>`
        : "");
    fillFold("syn", (d.synonyms || []).length,
      (d.synonyms || []).length
        ? `<div class="chips">${d.synonyms.slice(0, 8).map((s) => `<span class="chip" title="${esc(s.meaning)}">${esc(s.word)}</span>`).join("")}</div>`
        : "");
  }

  /** Drops a fold entirely when it turned out to have nothing in it. */
  function fillFold(slot, count, html) {
    const el = root.querySelector(`[data-fold="${slot}"]`);
    if (!el) return;
    if (!html) {
      el.remove();
      return;
    }
    el.querySelector("summary .count")?.remove();
    el.querySelector("summary").insertAdjacentHTML("beforeend", ` <span class="count">${count}</span>`);
    const body = el.querySelector(".fold-body");
    body.className = "fold-body";
    body.innerHTML = html;
  }

  // ─── Behaviour ─────────────────────────────────────────────────────────────

  /** Thin wrapper so a torn-down extension context reads as a normal error. */
  async function send(msg) {
    try {
      return await chrome.runtime.sendMessage(msg);
    } catch {
      return { ok: false, error: { message: "Extension was reloaded — refresh the page.", code: "CONTEXT" } };
    }
  }

  function savableFrom(result) {
    if (result?.type === "word" && result.found)
      return { term: result.word, translation: result.translation, entryKind: "word" };
    if (result?.type === "phrase" && result.found)
      return { term: result.phrase, translation: result.translation, entryKind: "phrase" };
    return null;
  }

  /** Only the fields tutor.contextChat's vocabContext accepts. */
  function vocabContextFrom(result) {
    if (result?.type === "word" && result.found) {
      return {
        term: result.word,
        translation: result.translation,
        wordType: result.wordType || undefined,
        pronunciation: result.pronunciation || undefined,
        grammar: result.grammar || undefined,
        examples: (result.examples || []).slice(0, 2),
        conjugationInfo: result.conjugationInfo || undefined,
        reflexiveInfo: result.reflexiveExplanation || undefined,
      };
    }
    if (result?.type === "phrase" && result.found) {
      return { term: result.phrase, translation: result.translation, pronunciation: result.pronunciation || undefined };
    }
    return null;
  }

  function onAction(e) {
    const act = e.currentTarget.dataset.act;
    if (act === "close") return close();
    if (act === "open") return send({ type: "OPEN_APP" });
    if (act === "micsetup") return send({ type: "OPEN_MIC_SETUP" });
    if (act === "speak") return speak(sayText || savableFrom(lastResult)?.term || ctx?.term);
    if (act === "retry") return runLookup(ctx);
    if (act === "save") return doSave(e.currentTarget);
    if (act === "ask") return doAsk();
  }

  async function doSave(btn) {
    const savable = savableFrom(lastResult);
    if (!savable || btn.disabled) return;
    btn.disabled = true;
    btn.textContent = "…";
    const res = await send({
      type: "SAVE_WORD",
      ...savable,
      source: ctx?.source ? `Web · ${ctx.source}` : "Web",
    });
    if (res.ok) {
      // The + becomes a green circled tick and stays that way — the green is
      // the reminder that this word is already in the library.
      btn.className = "addbtn saved";
      btn.textContent = "✓";
      btn.title = "In your library";
    } else {
      btn.disabled = false;
      btn.textContent = "+";
      btn.title = res.error?.code === "UNAUTHORIZED" ? "Sign in first — click ↗ Library below" : "Save failed — try again";
    }
  }

  function wireAskInput() {
    const input = card().querySelector("[data-ask]");
    // Typing must not reach the page's own hotkeys — or ours: Shift+Enter in
    // this box should mean "new line", exactly as it does in Tutor Chat.
    input?.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) doAsk();
      e.stopPropagation();
    });
  }

  async function doAsk() {
    const input = card().querySelector("[data-ask]");
    const slot = card().querySelector("[data-reply]");
    const question = input?.value.trim();
    if (!question || !slot) return;

    slot.innerHTML = `<div class="reply muted">Thinking…</div>`;
    input.value = "";

    const res = await send({
      type: "ASK",
      message: withPageContext(question),
      context: vocabContextFrom(lastResult),
    });
    slot.innerHTML = res.ok
      ? `<div class="reply md">${renderMarkdown(res.data?.reply)}</div>`
      : `<div class="reply err">${esc(res.error?.message || "Failed")}</div>`;
  }

  /**
   * contextChat's vocabContext is a fixed shape with no room for the page, so
   * the reading context rides along in the message. This is what makes the
   * answer about *this* sentence rather than the word in the abstract.
   */
  function withPageContext(question) {
    if (!ctx?.sentence && !ctx?.title) return question.slice(0, 2000);
    const where = [ctx.title && `“${ctx.title}”`, ctx.source].filter(Boolean).join(" — ");
    const suffix =
      `\n\n[Context: I'm reading ${where || "an article online"}.` +
      (ctx.term ? ` I highlighted: “${ctx.term}”.` : "") +
      (ctx.sentence ? ` The sentence is: “${ctx.sentence}”` : "") +
      `]`;
    return (question + suffix).slice(0, 2000);
  }

  /** True on success. Tries the async API, falls back to execCommand. */
  async function writeClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.cssText = "position:fixed;top:0;left:0;opacity:0";
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand("copy");
        ta.remove();
        return ok;
      } catch {
        return false;
      }
    }
  }

  async function runLookup(selection) {
    ctx = selection;
    lastResult = null;
    const seq = ++requestSeq;
    ensureCard();
    place(selection.rect);
    loading(selection.term);

    const res = await send({ type: "LOOKUP", term: selection.term });
    // Look up two words in quick succession and the first reply can land after
    // the second — drop anything that isn't the newest request.
    if (seq !== requestSeq) return;
    if (card().style.display === "none") return; // dismissed while loading
    if (!res.ok) return errorView(res.error);

    const { result, alreadySaved, hasRest } = res.data;
    lastResult = result;

    if (result?.type === "phrase") {
      result.found ? renderPhrase(result, alreadySaved) : renderNotFound(selection.term, seq);
      return;
    }
    if (result?.type === "question") return renderQuestion(result);
    if (result?.type !== "word") {
      return errorView({ message: result?.message || "Unexpected response", code: "PARSE" });
    }
    if (!result.found) return renderNotFound(selection.term, seq);

    renderWord(result, alreadySaved);
    void fillStages(result, seq, hasRest);
  }

  /**
   * Stages two and three, behind the painted card. Each is skipped when the
   * response already contains what it would have fetched — the server resolves
   * a light request from a richer cached entry, so a precomputed word arrives
   * complete and costs no further calls.
   */
  async function fillStages(meaning, seq, hasRest) {
    const headword = meaning.baseForm || meaning.word;
    let full = meaning;

    if (hasRest) {
      const res = await send({ type: "LOOKUP_REST", term: ctx.term });
      if (seq !== requestSeq) return;
      if (res.ok && res.data?.type === "word") {
        full = { ...meaning, ...res.data };
        // Keep the headword the meaning pass established, so the save button
        // and the audio cache key can't drift between stages.
        full.word = meaning.word;
        lastResult = full;
      }
    }
    if (seq !== requestSeq) return;
    fillFromRest(full);
    loadDetails(headword, seq, full.conjugations ? full : null);
    void loadContextNote(full, seq);
  }

  /**
   * The second half of "In this context": what this word is doing in the very
   * sentence it was highlighted in. Goes through the same contextChat endpoint
   * as the ask box, so the dictionary entry rides along as grounding.
   */
  async function loadContextNote(entry, seq) {
    const slot = root?.querySelector("[data-ctxnote]");
    if (!slot || !ctx?.sentence) return;
    const term = entry.word || ctx.term;
    const res = await send({
      type: "ASK",
      message:
        // The sentence is clamped on its own: the whole message gets cut at
        // 2000 chars, and a runaway "sentence" (bad extraction can grab a
        // whole paragraph) must not push the instructions after it off the
        // end — that is exactly when the reply drifts into French.
        `In 2-3 sentences of plain prose, explain in ENGLISH what "${term}" means in this sentence and how it functions there: "${String(ctx.sentence).slice(0, 1200)}". The explanation itself must be written in English — the reader is an English speaker learning French. Quoting French words or short phrases from the sentence is fine, but never answer in French prose. Talk about "${term}" ONLY — do NOT translate, analyze, or break down the rest of the sentence, and never go word by word. No bullets, no lists, no headings.`.slice(0, 2000),
      context: vocabContextFrom(entry),
    });
    if (seq !== requestSeq || !slot.isConnected) return;
    slot.innerHTML = res.ok
      ? `<div class="md">${renderMarkdown(res.data?.reply)}</div>`
      : `<span class="muted">Couldn't analyze this sentence.</span>`;
  }

  // ─── Voice question — push to talk on Alt+S ────────────────────────────────

  let voiceOpen = false;
  let voiceStopped = false;
  let voiceStartedAt = 0;

  /**
   * The transcribe-and-answer round trip gets a hard deadline. Without one, a
   * reply that never arrives (service worker evicted mid-request, offscreen
   * hang) left voiceOpen true forever — and since the keydown handler ignores
   * presses while a session is "open", every later Alt+S was swallowed without
   * a trace. A stuck flag must never outlive its session.
   */
  const VOICE_ANSWER_TIMEOUT_MS = 30_000;

  const WAVE_BARS = 30;
  const PILL_W = 268;
  /** Matches the website palette's max-w-2xl, clamped to the viewport. */
  const VOICE_W = 672;
  /** Scrolling window of recent levels, one per bar, newest on the right. */
  let waveLevels = new Array(WAVE_BARS).fill(0);

  /**
   * While the chord is held: a bare white pill holding nothing but the
   * waveform, like the OS dictation indicator. No header, no labels — the
   * moving bars are the entire message.
   */
  function renderPill() {
    ensureCard();
    const el = card();
    el.className = "card voice pill";
    el.style.maxHeight = "";
    waveLevels.fill(0);
    el.innerHTML = `<div class="wave" data-wave>${Array.from(
      { length: WAVE_BARS },
      // Staggered delays so the idle animation ripples instead of pulsing in
      // sync; real levels take over on the first VOICE_LEVEL tick.
      (_, i) => `<span style="animation-delay:${((i * 7) % 10) / 10}s"></span>`
    ).join("")}</div>`;
    centerVoice(PILL_W);
  }

  /** One tick of the meter, relayed from the offscreen recorder. */
  function pushLevel(level) {
    const wave = root?.querySelector("[data-wave]");
    if (!wave) return;
    wave.classList.add("live");
    waveLevels.push(Math.max(0.02, Math.min(1, level)));
    waveLevels.shift();
    const bars = wave.children;
    for (let i = 0; i < bars.length; i++) {
      bars[i].style.height = `${Math.round(4 + waveLevels[i] * 32)}px`;
    }
  }

  /**
   * On release the pill grows into the answer card. Same element, so the CSS
   * transition carries width, height and corner radius through the morph.
   */
  /**
   * The card grows in phases, VoiceOS-style: "mid" is just tall enough for the
   * transcript, "full" opens up for the answer. Inline max-height is what the
   * CSS transition animates, so each phase change is a smooth extension rather
   * than a jump.
   */
  function expandVoice(innerHtml, phase = "full") {
    ensureCard();
    const el = card();
    el.className = "card voice expanded";
    el.style.maxHeight = phase === "mid" ? "260px" : "min(60vh, 520px)";
    el.innerHTML = `<div class="vbody">${innerHtml}</div>`;
    el.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", onAction));
    centerVoice(Math.min(VOICE_W, window.innerWidth - 2 * MARGIN));
  }

  /**
   * The question card, constant across all phases: highlighted context on top
   * in bold burgundy, the question beneath it in black, and the controls (▶
   * once there is an answer to hear, ✕ always) inside the card's corner.
   * `questionHtml` arrives pre-escaped so phases can pass placeholders.
   */
  function qboxHtml(questionHtml, { say = false } = {}) {
    const hasCtx = !!ctx?.term;
    return `<div class="qbox">
        <div class="qactions">
          ${say ? `<button class="say" data-act="speak" data-state="idle" title="Hear the answer">▶</button>` : ""}
          <button class="vclose" data-act="close" title="Close (Esc)">✕</button>
        </div>
        ${hasCtx ? `<div class="qctx">« ${esc(ctx.term)} »</div>` : ""}
        <div class="qa-q${hasCtx ? "" : " lone"}">${questionHtml}</div>
      </div>`;
  }

  const withVoiceTimeout = (p) =>
    Promise.race([
      p,
      new Promise((resolve) =>
        setTimeout(
          () => resolve({ ok: false, error: { code: "TIMEOUT", message: "No answer after 30 seconds — try again." } }),
          VOICE_ANSWER_TIMEOUT_MS
        )
      ),
    ]);

  async function startVoice(selection) {
    ctx = selection;
    voiceOpen = true;
    voiceStopped = false;
    voiceStartedAt = Date.now();
    renderPill();

    const res = await send({ type: "VOICE_START" });
    // The keys may have been released while getUserMedia was still coming up;
    // stopVoice already ran and the pill is gone. Don't resurrect an error card.
    if (!res.ok && voiceOpen) {
      voiceOpen = false;
      voiceStopped = true;
      return voiceError(res.error);
    }
  }

  async function stopVoice() {
    if (!voiceOpen || voiceStopped) return;
    voiceStopped = true;

    // Phase 1 — the question card appears at once, context already on top,
    // with a placeholder where the transcript is about to land.
    expandVoice(qboxHtml(`<span class="muted" style="font-style:italic">Transcribing…</span>`), "mid");

    const t = await withVoiceTimeout(send({ type: "VOICE_TRANSCRIBE" }));
    if (t.error?.code === "TIMEOUT") send({ type: "VOICE_ABORT" }); // mic may still be held
    if (!t.ok) {
      voiceOpen = false;
      return voiceError(t.error);
    }
    const question = t.data?.question || "";

    // Phase 2 — the transcript fills the card the moment it exists, thinking
    // dots below while the tutor works. The watchdog restarts: a new wait.
    voiceStartedAt = Date.now();
    expandVoice(
      `${qboxHtml(esc(question))}<div class="dots"><span></span><span></span><span></span></div>`,
      "mid"
    );

    const r = await withVoiceTimeout(send({ type: "VOICE_ANSWER", question, context: ctx?.term || undefined }));
    voiceOpen = false;
    if (!r.ok) return voiceError(r.error);

    // Phase 3 — the card extends for the answer, and ▶ joins ✕ inside the
    // question card now there is something to read aloud.
    const reply = r.data?.reply || "";
    expandVoice(
      `${qboxHtml(esc(question), { say: true })}
       <div data-copyslot></div>
       <div class="vreply md">${renderMarkdown(reply)}</div>
       <div class="vfoot">
         <img class="brand-logo" data-act="open" src="${chrome.runtime.getURL("brand/wordmark.png")}" alt="RomainTalk" title="Open romaintalk.com" />
         <span class="vnote">Hold ${navigator.platform.startsWith("Mac") ? "⌥S" : "Alt+S"} to ask again</span>
       </div>`,
      "full"
    );
    // voice.tts caps input at 500 chars, so long replies are trimmed.
    sayText = plainText(reply).slice(0, 500);
    if (sayText) preloadAudio(sayText);

    // Writing helper: the clean phrase goes to the clipboard, and the card
    // says so — or offers a manual Copy when the write fails (a page that has
    // lost focus, as in the Google Docs case, can refuse programmatic copies).
    if (r.data?.copyText) void showCopyRow(r.data.copyText);
  }

  async function showCopyRow(text) {
    const slot = root?.querySelector("[data-copyslot]");
    if (!slot) return;
    const ok = await writeClipboard(text);
    slot.innerHTML = `<div class="copyrow">
        <span class="copyphrase">« ${esc(text)} »</span>
        ${ok
          ? `<span class="copied">✓ Copied — just paste</span>`
          : `<button class="copybtn" data-act="copyagain">📋 Copy</button>`}
      </div>`;
    slot.querySelector('[data-act="copyagain"]')?.addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      if (await writeClipboard(text)) {
        btn.outerHTML = `<span class="copied">✓ Copied — just paste</span>`;
      }
    });
  }

  function voiceError(err) {
    voiceOpen = false;
    const needsGrant = err?.code === "MIC_DENIED";
    expandVoice(
      `<div class="vhead"><button class="vclose" data-act="close" title="Close (Esc)">✕</button></div>
       <div class="center" style="padding:0 0 4px">
         <p class="err" style="font-weight:600;margin-bottom:5px">${needsGrant ? "Microphone not enabled" : "Couldn't ask"}</p>
         <p class="muted">${esc(err?.message || "Something went wrong")}</p>
         ${needsGrant
           ? `<div class="actions" style="margin-top:14px"><button class="btn primary" data-act="micsetup">Enable microphone</button></div>
              <div class="vnote" style="margin-top:8px">Asked once, for the extension — not per site.</div>`
           : ""}
       </div>`
    );
  }

  // ─── Prefetch on selection ─────────────────────────────────────────────────

  /**
   * You highlight a word, then reach for the shortcut. That gap is a few hundred
   * milliseconds of otherwise wasted time, so the lookup starts when the
   * selection settles rather than when the key lands — by which point the answer
   * is often already cached and the card paints with no network at all.
   *
   * Speculative work costs tokens, so it is kept deliberately narrow: single
   * words only, nothing already fetched this session, one at a time, and off
   * entirely while a card is open (you're reading, not selecting).
   */
  const PREFETCH_DEBOUNCE_MS = 350;
  const PREFETCH_MIN_GAP_MS = 1200;
  const prefetched = new Set();
  let prefetchEnabled = true;
  let prefetchTimer = null;
  let lastPrefetchAt = 0;

  void (async () => {
    prefetchEnabled = (await readSetting("prefetch", true)) !== false;
  })();

  try {
    chrome.storage?.onChanged?.addListener((changes, area) => {
      if (area === "local" && changes.prefetch) prefetchEnabled = changes.prefetch.newValue !== false;
    });
  } catch { /* no storage events in the dev harness */ }

  /** Single French-looking word, long enough to be worth a lookup. */
  function prefetchable(text) {
    return (
      text.length >= 3 &&
      text.length <= 30 &&
      !/\s/.test(text) &&
      /^[\p{L}'’-]+$/u.test(text) &&
      !prefetched.has(text.toLowerCase())
    );
  }

  document.addEventListener("selectionchange", () => {
    if (standDown || !prefetchEnabled || isOpen()) return;
    clearTimeout(prefetchTimer);
    prefetchTimer = setTimeout(() => {
      if (isOpen() || Date.now() - lastPrefetchAt < PREFETCH_MIN_GAP_MS) return;
      const text = (window.getSelection()?.toString() || "").trim();
      if (!prefetchable(text)) return;
      prefetched.add(text.toLowerCase());
      lastPrefetchAt = Date.now();
      // Fire and forget — the point is only to warm the caches.
      send({ type: "LOOKUP", term: text, prefetch: true });
    }, PREFETCH_DEBOUNCE_MS);
  });

  // ─── Shortcuts ─────────────────────────────────────────────────────────────

  /**
   * True when the user is typing. Mirrors Home.tsx's guard, plus a shadow-root
   * check: focus inside our own card retargets to the host, which is a DIV, so
   * the plain tagName test would wave it through.
   */
  function isTyping() {
    const el = document.activeElement;
    if (!el) return false;
    const inner = el === host ? root?.activeElement : el;
    if (!inner) return false;
    return inner.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(inner.tagName);
  }

  document.addEventListener("keydown", (e) => {
    if (standDown) return;
    if (!e.altKey || e.metaKey || e.ctrlKey || e.shiftKey) return;

    // Matched on `code` (the physical key), never `key`: on macOS, Option
    // rewrites the character — Alt+D arrives as "∂" and Alt+S as "ß" — and on
    // AZERTY the letters move. The physical key stays put.

    // Alt+D — dictionary. Normally the chrome.commands binding fires instead
    // and this branch never sees the event (a bound command consumes the
    // keystroke); it exists for when another extension owns the chord.
    if (e.code === "KeyD") {
      if (isTyping()) return;
      const selection = currentSelection();
      if (!selection) return;
      e.preventDefault();
      runLookup(selection);
      return;
    }

    // Alt+S — push to talk. Deliberately NOT guarded by isTyping: the voice
    // palette should open even from a Google Doc or a search bar — capture
    // phase runs before the field's own handlers, and preventDefault stops the
    // "ß" macOS would otherwise type. Selection stays optional too; without
    // one the question simply has no context. Auto-repeat would restart it.
    if (e.code === "KeyS") {
      // Repeats are swallowed too, or holding the chord in a text field would
      // type a stream of "ß" while the mic records.
      if (e.repeat) { e.preventDefault(); return; }
      e.preventDefault();
      e.stopPropagation();
      if (voiceOpen) {
        // Self-heal: if a previous session wedged (its answer never came back,
        // so voiceOpen was never cleared), a stale flag must not eat every
        // future press. Anything older than the answer watchdog is dead.
        if (Date.now() - voiceStartedAt < VOICE_ANSWER_TIMEOUT_MS + 5000) return;
        voiceOpen = false;
      }
      startVoice(currentSelection());
    }
  }, true);

  // Letting go of either key ends the recording; there's no telling which one
  // the user lifts first. Alt release reports e.key "Alt"; the S release can
  // report "ß" on macOS, so it's matched on code.
  document.addEventListener("keyup", (e) => {
    if (e.key !== "Alt" && e.code !== "KeyS") return;
    if (voiceOpen) stopVoice();
  }, true);

  // Losing the window mid-hold would otherwise leave the mic running.
  window.addEventListener("blur", () => {
    if (voiceOpen) stopVoice();
  });

  // ─── Context-menu entry points ─────────────────────────────────────────────

  function runAsk(selection) {
    ctx = selection;
    lastResult = null;
    ensureCard();
    place(selection.rect);
    shell(
      dhead(`<span class="dterm">${esc(selection.term)}</span>`),
      selection.sentence && selection.sentence !== selection.term
        ? `<div class="folds">${fold("In context", "", `<div class="muted">${esc(selection.sentence)}</div>`)}</div>` : "",
      footer({ savable: false })
    );
    wireAskInput();
    card().querySelector("[data-ask]")?.focus();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (standDown) return;
    if (msg?.type === "VOICE_LEVEL") {
      if (voiceOpen && !voiceStopped) pushLevel(msg.level);
      return;
    }
    // Chords relayed by keyhook.js from a subframe — Google Docs' hidden input
    // frame and the like — where this script doesn't run. Same semantics as
    // the local key handlers, including the wedge self-heal.
    if (msg?.type === "TRIGGER_VOICE_DOWN") {
      if (voiceOpen) {
        if (Date.now() - voiceStartedAt < VOICE_ANSWER_TIMEOUT_MS + 5000) return;
        voiceOpen = false;
      }
      startVoice(currentSelection());
      return;
    }
    if (msg?.type === "TRIGGER_VOICE_UP") {
      if (voiceOpen) stopVoice();
      return;
    }
    if (msg?.type !== "TRIGGER_LOOKUP" && msg?.type !== "TRIGGER_ASK") return;
    const selection = currentSelection(msg.selection);
    if (!selection) return;
    msg.type === "TRIGGER_LOOKUP" ? runLookup(selection) : runAsk(selection);
  });
})();
