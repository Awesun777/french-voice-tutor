/**
 * permission.js — the one place the microphone can actually be granted.
 *
 * This runs as a normal tab, which matters: in a browser-action popup, Chrome
 * rejects getUserMedia outright. The popup loses focus to the permission bubble
 * and is torn down, so the request dies before the user can answer — no prompt
 * is shown and, tellingly, no BLOCK entry is recorded in Chrome's content
 * settings either. A tab survives the prompt, and because it is the same
 * chrome-extension:// origin, the offscreen recorder inherits the grant.
 */
const btn = document.getElementById("grant");
const result = document.getElementById("result");

function show(cls, text, detail = "") {
  result.className = `result ${cls}`;
  result.innerHTML = `${text}${detail ? `<div class="detail">${detail}</div>` : ""}`;
}

async function refresh() {
  try {
    const status = await navigator.permissions.query({ name: "microphone" });
    if (status.state === "granted") {
      show("ok", "✓ Microphone enabled", "You can close this tab — Alt+S works now.");
      btn.disabled = true;
      btn.textContent = "Already enabled";
    }
  } catch {
    // Permissions.query isn't reliable for every origin type; the button still works.
  }
}

btn.onclick = async () => {
  btn.disabled = true;
  show("", "Waiting for Chrome's prompt…");
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    // The grant is the point; we don't want the audio itself.
    stream.getTracks().forEach((t) => t.stop());
    show("ok", "✓ Microphone enabled", "You can close this tab — Alt+S works now.");
    btn.textContent = "Enabled";
  } catch (err) {
    btn.disabled = false;
    const name = err?.name || "Error";
    const detail =
      name === "NotAllowedError"
        ? "Chrome blocked it. If no prompt appeared, check macOS System Settings → Privacy & Security → Microphone → Google Chrome."
        : name === "NotFoundError"
          ? "No microphone was found on this machine."
          : String(err?.message || err);
    show("bad", "Couldn't enable the microphone", `${name} — ${detail}`);
  }
};

refresh();

// ─── Self-test ───────────────────────────────────────────────────────────────

/**
 * "The microphone doesn't work" has at least four distinct causes, and the
 * card's one error line can't separate them. This drives the real offscreen
 * recording path with no transcription, no network and no keyboard shortcut in
 * the way, so the result says plainly whether the fault is the mic or something
 * after it.
 */
const test = document.getElementById("test");
const steps = document.getElementById("steps");

test.onclick = async () => {
  test.disabled = true;
  steps.style.display = "block";
  steps.textContent = "Recording 1.5s — say something…";
  show("", "Testing…");

  const res = await chrome.runtime.sendMessage({ type: "VOICE_TEST" });
  test.disabled = false;

  const data = res?.ok ? res.data : null;
  const lines = (data?.steps || []).map((s) => `  ${s}`).join("\n");

  if (data?.ok) {
    show("ok", "✓ Recording works");
    steps.textContent = `${lines}\n\nThe microphone path is fine. If Alt+S still does nothing on a\npage, the shortcut is being swallowed there — try the right-click menu.`;
  } else {
    const err = data?.error || res?.error?.message || "unknown failure";
    show("bad", "Recording failed");
    steps.textContent = `${lines}\n\n${err}`;
  }
};
